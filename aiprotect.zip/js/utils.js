/* ============================================================
   AI PROTECT — UTILITIES
   ============================================================ */

window.Utils = {

  // ── Severity ────────────────────────────────────────────────
  severityConfig: {
    CRITICAL: { color: '#ff3366', bg: 'rgba(255,51,102,0.12)', icon: '🔴', rank: 4 },
    HIGH:     { color: '#ff6b35', bg: 'rgba(255,107,53,0.12)',  icon: '🟠', rank: 3 },
    MEDIUM:   { color: '#ffb800', bg: 'rgba(255,184,0,0.12)',   icon: '🟡', rank: 2 },
    LOW:      { color: '#00ff88', bg: 'rgba(0,255,136,0.12)',   icon: '🟢', rank: 1 },
    INFO:     { color: '#00c8ff', bg: 'rgba(0,200,255,0.10)',   icon: '🔵', rank: 0 },
  },

  severityBadge(level) {
    const cfg = this.severityConfig[level] || this.severityConfig['INFO'];
    return `<span class="severity-badge" style="background:${cfg.bg};color:${cfg.color};border-color:${cfg.color}40">${cfg.icon} ${level}</span>`;
  },

  severityColor(level) {
    return (this.severityConfig[level] || this.severityConfig['INFO']).color;
  },

  // ── Confidence Bar ──────────────────────────────────────────
  confidenceBar(pct, label) {
    const color = pct >= 85 ? '#ff3366' : pct >= 60 ? '#ffb800' : '#00ff88';
    return `<div class="confidence-wrap">
      ${label ? `<span class="confidence-label">${label}</span>` : ''}
      <div class="confidence-track">
        <div class="confidence-fill" style="width:${pct}%;background:${color}" data-pct="${pct}"></div>
      </div>
      <span class="confidence-pct" style="color:${color}">${pct}%</span>
    </div>`;
  },

  // ── Timestamps ──────────────────────────────────────────────
  now() {
    return new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  },

  timeAgo(seconds) {
    if (seconds < 60)   return `${seconds}s ago`;
    if (seconds < 3600) return `${Math.floor(seconds/60)}m ago`;
    return `${Math.floor(seconds/3600)}h ago`;
  },

  randomTime(hoursBack = 24) {
    const d = new Date(Date.now() - Math.random() * hoursBack * 3600000);
    return d.toISOString().replace('T', ' ').slice(0, 19);
  },

  // ── IP / Network helpers ────────────────────────────────────
  randomIP(suspicious = false) {
    if (suspicious) {
      const pools = ['185.220.', '45.142.', '193.32.', '91.108.', '198.199.'];
      const pool  = pools[Math.floor(Math.random() * pools.length)];
      return pool + (Math.floor(Math.random() * 254) + 1) + '.' + (Math.floor(Math.random() * 254) + 1);
    }
    return `${Math.floor(Math.random()*254)+1}.${Math.floor(Math.random()*254)+1}.${Math.floor(Math.random()*254)+1}.${Math.floor(Math.random()*254)+1}`;
  },

  randomPort() {
    const ports = [22, 23, 25, 80, 443, 3306, 5432, 8080, 8443, 9200, 6379, 27017];
    return ports[Math.floor(Math.random() * ports.length)];
  },

  geoFromIP(ip) {
    const geos = ['Moscow, RU', 'Beijing, CN', 'Lagos, NG', 'Kyiv, UA', 'Tehran, IR', 'Hanoi, VN', 'Minsk, BY', 'Bucharest, RO'];
    return geos[Math.floor(Math.random() * geos.length)];
  },

  // ── Random helpers ──────────────────────────────────────────
  randomBetween(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  },

  randomChoice(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  },

  randomHash(len = 32) {
    const chars = '0123456789abcdef';
    return Array.from({length: len}, () => chars[Math.floor(Math.random() * 16)]).join('');
  },

  randomHex(len = 8) {
    return this.randomHash(len);
  },

  // ── String helpers ──────────────────────────────────────────
  truncate(str, n = 60) {
    return str.length > n ? str.slice(0, n) + '…' : str;
  },

  escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  },

  // ── Export helpers ──────────────────────────────────────────
  downloadJSON(data, filename) {
    const blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
    this._download(blob, filename);
  },

  downloadCSV(rows, headers, filename) {
    const csv = [headers.join(','), ...rows.map(r => headers.map(h => `"${String(r[h]||'').replace(/"/g,'""')}"`).join(','))].join('\n');
    const blob = new Blob([csv], {type: 'text/csv'});
    this._download(blob, filename);
  },

  downloadText(text, filename) {
    const blob = new Blob([text], {type: 'text/plain'});
    this._download(blob, filename);
  },

  _download(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a   = document.createElement('a');
    a.href = url; a.download = filename; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  },

  // ── Animated number counter ─────────────────────────────────
  animateCount(el, target, duration = 800, suffix = '') {
    let startTime = null;
    const step  = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      el.textContent = Math.floor(progress * target) + suffix;
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  },

  // ── Delay ───────────────────────────────────────────────────
  sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
  },

  // ── Typewriter effect ───────────────────────────────────────
  async typewrite(el, text, speed = 18) {
    el.textContent = '';
    for (const char of text) {
      el.textContent += char;
      await this.sleep(speed);
    }
  },

  // ── Notifications ───────────────────────────────────────────
  notify(message, type = 'info', duration = 4000) {
    const colors = {
      info:    '#00c8ff',
      success: '#00ff88',
      warning: '#ffb800',
      error:   '#ff3366',
    };
    const icons = { info: 'ℹ', success: '✓', warning: '⚠', error: '✕' };
    const color  = colors[type] || colors.info;
    const icon   = icons[type] || icons.info;

    const el = document.createElement('div');
    el.className = 'global-notif';
    el.style.cssText = `
      position:fixed;top:80px;right:20px;z-index:9999;
      background:rgba(2,11,24,0.95);
      border:1px solid ${color}40;
      border-left:3px solid ${color};
      padding:12px 16px;border-radius:8px;
      font-size:13px;color:#e0e0e0;
      animation:notif-in 0.3s ease;
      max-width:360px;backdrop-filter:blur(20px);
      display:flex;align-items:center;gap:10px;
    `;
    el.innerHTML = `<span style="color:${color};font-size:16px;font-weight:700">${icon}</span><span>${message}</span>`;
    document.body.appendChild(el);
    setTimeout(() => {
      el.style.animation = 'notif-out 0.3s ease forwards';
      setTimeout(() => el.remove(), 300);
    }, duration);
  },

  // ── Format bytes ────────────────────────────────────────────
  formatBytes(bytes) {
    if (bytes < 1024)       return bytes + ' B';
    if (bytes < 1048576)    return (bytes/1024).toFixed(1) + ' KB';
    if (bytes < 1073741824) return (bytes/1048576).toFixed(1) + ' MB';
    return (bytes/1073741824).toFixed(1) + ' GB';
  },

  // ── Code pointer card ───────────────────────────────────────
  codePointer(file, line, snippet, issue) {
    return `<div class="code-pointer">
      <div class="code-pointer-loc">
        <span class="code-file">📄 ${file}</span>
        <span class="code-line">Line ${line}</span>
      </div>
      <pre class="code-snippet"><code>${this.escapeHtml(snippet)}</code></pre>
      <div class="code-issue">⚠ ${issue}</div>
    </div>`;
  },

  // ── Animate progress bars ───────────────────────────────────
  animateProgressBars() {
    document.querySelectorAll('.confidence-fill[data-pct]').forEach(bar => {
      const pct = bar.dataset.pct;
      bar.style.width = '0%';
      setTimeout(() => {
        bar.style.transition = 'width 0.8s cubic-bezier(0.4,0,0.2,1)';
        bar.style.width = pct + '%';
      }, 100);
    });
  },
};
