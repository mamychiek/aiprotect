/* ============================================================
   AI PROTECT — AGENT 2: Small Business Security Monitor
   ============================================================ */

window.BizMonitorAgent = (() => {

  let running = false;
  let logInterval = null;
  let alertInterval = null;
  let logCount = 0;
  let threatCount = 0;
  let blockedIPs = new Set();
  let alertLog = [];
  let bruteForceTracker = {};

  const LOG_SOURCES = ['auth.log', 'firewall.log', 'api-access.log', 'syslog', 'vpn.log'];
  const USERS = ['admin', 'root', 'jenkins', 'ubuntu', 'deploy', 'postgres', 'guest', 'service_acct'];
  const LEGIT_IPS = ['10.0.1.5', '10.0.1.12', '192.168.1.100', '192.168.1.45'];

  const THREAT_PATTERNS = [
    {
      id: 'brute_force',
      title: 'SSH Brute Force Attack Detected',
      mitreId: 'T1110',
      severity: 'CRITICAL',
      icon: '🔑',
      confidence: () => Utils.randomBetween(87, 98),
      remediation: 'Immediately block the source IP. Enable fail2ban or equivalent.',
      remCmd: 'iptables -A INPUT -s {IP} -j DROP && echo "Blocked {IP}" >> /var/log/blocked.log',
    },
    {
      id: 'port_scan',
      title: 'Port Scan / Reconnaissance Detected',
      mitreId: 'T1046',
      severity: 'HIGH',
      icon: '🔍',
      confidence: () => Utils.randomBetween(82, 96),
      remediation: 'Block scanning IP at firewall perimeter. Review exposed services.',
      remCmd: 'ufw deny from {IP} to any',
    },
    {
      id: 'priv_esc',
      title: 'Privilege Escalation Attempt',
      mitreId: 'T1548',
      severity: 'CRITICAL',
      icon: '⬆️',
      confidence: () => Utils.randomBetween(88, 99),
      remediation: 'Lock affected user account. Audit sudo configuration immediately.',
      remCmd: 'usermod -L {USER} && last -a | grep {USER} >> /var/log/audit/priv-esc.log',
    },
    {
      id: 'suspicious_outbound',
      title: 'Suspicious Outbound C2 Connection',
      mitreId: 'T1071',
      severity: 'HIGH',
      icon: '📡',
      confidence: () => Utils.randomBetween(80, 94),
      remediation: 'Block outbound connection. Isolate host and perform memory forensics.',
      remCmd: 'iptables -A OUTPUT -d {IP} -j DROP && ss -tupn | grep {IP}',
    },
    {
      id: 'api_abuse',
      title: 'API Rate Limit Abuse / Credential Stuffing',
      mitreId: 'T1110',
      severity: 'HIGH',
      icon: '🌐',
      confidence: () => Utils.randomBetween(78, 92),
      remediation: 'Enable IP-based rate limiting. Trigger CAPTCHA on failed auth sequences.',
      remCmd: 'nginx: limit_req_zone $binary_remote_addr zone=api:10m rate=10r/m;',
    },
    {
      id: 'data_exfil',
      title: 'Potential Data Exfiltration Detected',
      mitreId: 'T1041',
      severity: 'CRITICAL',
      icon: '💾',
      confidence: () => Utils.randomBetween(85, 97),
      remediation: 'Block outbound transfer. Snapshot disk. Begin incident response.',
      remCmd: 'tcpdump -i eth0 -w /evidence/capture.pcap host {IP}',
    },
  ];

  // ── Render ─────────────────────────────────────────────────
  function render() {
    return `
    <div class="agent-hero">
      <div class="agent-hero-left">
        <div class="agent-hero-icon" style="background:linear-gradient(135deg,#ff3366,#cc0044)">🛡️</div>
        <div>
          <div class="agent-hero-title">Security Monitoring Agent</div>
          <div class="agent-hero-sub">Real-time log ingestion · Threat detection · MITRE ATT&CK · WhatsApp & Telegram alerts</div>
        </div>
      </div>
      <div class="agent-hero-right">
        <div class="toggle-wrap" onclick="BizMonitorAgent.toggleMonitoring(this)">
          <div class="toggle" id="bm-toggle"></div>
          <span style="font-size:13px;color:var(--text-secondary)" id="bm-toggle-label">Monitoring OFF</span>
        </div>
      </div>
    </div>

    <!-- Stats Row -->
    <div class="dashboard-grid" style="margin-bottom:20px">
      <div class="stat-card" style="--card-accent:#00ff88">
        <span class="stat-card-icon">📥</span>
        <div class="stat-card-value" id="bm-log-count">0</div>
        <div class="stat-card-label">Logs Ingested</div>
      </div>
      <div class="stat-card" style="--card-accent:#ff3366">
        <span class="stat-card-icon">⚡</span>
        <div class="stat-card-value" id="bm-threat-count">0</div>
        <div class="stat-card-label">Threats Detected</div>
      </div>
      <div class="stat-card" style="--card-accent:#ffb800">
        <span class="stat-card-icon">🔒</span>
        <div class="stat-card-value" id="bm-blocked-count">0</div>
        <div class="stat-card-label">IPs Blocked</div>
      </div>
      <div class="stat-card" style="--card-accent:#7c3aed">
        <span class="stat-card-icon">📡</span>
        <div class="stat-card-value" id="bm-alert-count">0</div>
        <div class="stat-card-label">Alerts Sent</div>
      </div>
    </div>

    <div class="grid-2" style="gap:16px">
      <!-- Log Feed Terminal -->
      <div>
        <div class="section-title">Live Log Feed</div>
        <div class="terminal">
          <div class="terminal-header">
            <div class="terminal-dots">
              <div class="terminal-dot red"></div>
              <div class="terminal-dot amber"></div>
              <div class="terminal-dot green"></div>
            </div>
            <span class="terminal-title">security-agent@monitor:~$</span>
            <div class="wave-bars" id="bm-wave" style="margin-left:auto">
              ${Array.from({length:8}, (_,i) =>
                `<div class="wave-bar" style="height:${8+i*3}px;animation:wave ${0.6+i*0.1}s ease-in-out ${i*80}ms infinite;opacity:0.3" id="bm-wave-bar-${i}"></div>`
              ).join('')}
            </div>
          </div>
          <div class="terminal-body" id="bm-log-feed">
            <div class="log-line">
              <span class="log-time">00:00:00</span>
              <span class="log-level INFO">INFO</span>
              <span class="log-msg">Security monitor initialized. Click toggle to start ingestion.</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Threat Alerts Panel -->
      <div>
        <div class="section-title">Threat Alerts
          <button class="btn btn-ghost btn-sm" style="margin-left:auto" onclick="BizMonitorAgent.clearAlerts()">Clear</button>
        </div>
        <div id="bm-alerts-panel" style="display:flex;flex-direction:column;gap:8px;max-height:360px;overflow-y:auto">
          <div class="empty-state" style="padding:32px">
            <div class="empty-state-icon">🛡️</div>
            <div class="empty-state-text">No threats detected yet</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Audit Log Table -->
    <div style="margin-top:20px">
      <div class="section-title">Alert Audit Log</div>
      <div class="data-table-wrap" id="bm-audit-wrap">
        <table class="data-table" id="bm-audit-table">
          <thead><tr>
            <th>Time</th><th>Threat</th><th>Source IP</th>
            <th>Geo</th><th>MITRE</th><th>Severity</th><th>Confidence</th>
          </tr></thead>
          <tbody id="bm-audit-body">
            <tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:24px">No alerts logged yet</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Alert Modal (WhatsApp/Telegram) -->
    <div class="modal-overlay hidden" id="bm-alert-modal">
      <div class="modal-box">
        <div class="modal-header">
          <div class="modal-title">📱 Alert Dispatch</div>
          <button class="modal-close" onclick="document.getElementById('bm-alert-modal').classList.add('hidden')">✕</button>
        </div>
        <div id="bm-modal-content"></div>
      </div>
    </div>
    `;
  }

  // ── Toggle Monitoring ───────────────────────────────────────
  function toggleMonitoring(wrap) {
    const toggle = document.getElementById('bm-toggle');
    const label  = document.getElementById('bm-toggle-label');
    running = !running;
    toggle.classList.toggle('on', running);
    label.textContent = running ? 'Monitoring LIVE' : 'Monitoring OFF';
    label.style.color = running ? 'var(--accent-green)' : 'var(--text-secondary)';

    // Animate wave bars
    document.querySelectorAll('[id^="bm-wave-bar-"]').forEach(b => {
      b.style.opacity = running ? '1' : '0.3';
    });

    if (running) {
      startMonitoring();
      Utils.notify('Security monitoring started — ingesting logs', 'success');
    } else {
      stopMonitoring();
      Utils.notify('Security monitoring paused', 'info');
    }
  }

  function startMonitoring() {
    // Log stream every 800ms–1.4s
    logInterval = setInterval(generateLog, Utils.randomBetween(600, 1200));
    // Threat detection every 6–12s
    alertInterval = setInterval(maybeDetectThreat, Utils.randomBetween(6000, 12000));
  }

  function stopMonitoring() {
    clearInterval(logInterval);
    clearInterval(alertInterval);
  }

  // ── Log Generation ──────────────────────────────────────────
  function generateLog() {
    if (!running) return;

    const types = [
      () => ({ level: 'INFO',    msg: `[${Utils.randomChoice(LOG_SOURCES)}] Accepted connection from ${Utils.randomChoice(LEGIT_IPS)} port ${Utils.randomBetween(1024,65535)}` }),
      () => ({ level: 'INFO',    msg: `[auth.log] Successful login for user '${Utils.randomChoice(USERS)}' from ${Utils.randomChoice(LEGIT_IPS)}` }),
      () => ({ level: 'INFO',    msg: `[api-access.log] GET /api/v2/data 200 ${Utils.randomBetween(20,400)}ms` }),
      () => ({ level: 'INFO',    msg: `[firewall.log] ALLOW TCP ${Utils.randomChoice(LEGIT_IPS)}:${Utils.randomBetween(1024,9999)} -> 10.0.0.1:443` }),
      () => ({ level: 'WARN',    msg: `[auth.log] Failed login attempt for '${Utils.randomChoice(USERS)}' from ${Utils.randomIP(true)}` }),
      () => ({ level: 'WARN',    msg: `[firewall.log] BLOCK UDP ${Utils.randomIP(true)}:${Utils.randomBetween(1,1024)} -> MULTICAST` }),
      () => ({ level: 'INFO',    msg: `[syslog] cron: (root) CMD (/usr/sbin/logrotate /etc/logrotate.conf)` }),
      () => ({ level: 'INFO',    msg: `[vpn.log] Tunnel established for user ${Utils.randomChoice(USERS)} (${Utils.randomIP()})` }),
      () => ({ level: 'DEBUG',   msg: `[api-access.log] POST /api/auth/login 401 ${Utils.randomBetween(5,50)}ms` }),
      () => ({ level: 'ERROR',   msg: `[auth.log] pam_unix(sshd:auth): authentication failure; user=${Utils.randomChoice(USERS)} rhost=${Utils.randomIP(true)}` }),
    ];

    const entry = Utils.randomChoice(types)();
    const now   = new Date().toTimeString().slice(0, 8);

    const feed = document.getElementById('bm-log-feed');
    if (!feed) return;

    const line = document.createElement('div');
    line.className = 'log-line';
    line.innerHTML = `
      <span class="log-time">${now}</span>
      <span class="log-level ${entry.level}">${entry.level}</span>
      <span class="log-msg">${entry.msg}</span>
    `;
    feed.appendChild(line);

    // Keep max 80 lines
    while (feed.children.length > 80) feed.removeChild(feed.firstChild);
    feed.scrollTop = feed.scrollHeight;

    logCount++;
    const lc = document.getElementById('bm-log-count');
    if (lc) lc.textContent = logCount;
  }

  // ── Threat Detection ────────────────────────────────────────
  function maybeDetectThreat() {
    if (!running) return;
    if (Math.random() > 0.65) return; // 65% chance each interval

    const pattern   = Utils.randomChoice(THREAT_PATTERNS);
    const ip        = Utils.randomIP(true);
    const geo       = Utils.geoFromIP(ip);
    const confidence= pattern.confidence();
    const user      = Utils.randomChoice(USERS);

    if (confidence < 85) return; // Only fire if > 85%

    const time = new Date().toISOString().replace('T',' ').slice(0,19);
    const alert = { ...pattern, ip, geo, confidence, time, user };
    alertLog.push(alert);
    threatCount++;
    blockedIPs.add(ip);

    // Update counters
    const tc = document.getElementById('bm-threat-count'); if (tc) tc.textContent = threatCount;
    const bc = document.getElementById('bm-blocked-count'); if (bc) bc.textContent = blockedIPs.size;
    const ac = document.getElementById('bm-alert-count');  if (ac) ac.textContent = threatCount;

    // Render alert card
    renderAlertCard(alert);

    // Add to audit log
    addAuditRow(alert);

    // Log to terminal
    const feed = document.getElementById('bm-log-feed');
    if (feed) {
      const line = document.createElement('div');
      line.className = 'log-line';
      line.innerHTML = `
        <span class="log-time">${new Date().toTimeString().slice(0,8)}</span>
        <span class="log-level ERROR">ALERT</span>
        <span class="log-msg" style="color:var(--accent-red);font-weight:600">
          🚨 ${pattern.title} from ${ip} [${confidence}% confidence]
        </span>
      `;
      feed.appendChild(line);
      feed.scrollTop = feed.scrollHeight;
    }

    // Show dispatch modal for critical
    if (pattern.severity === 'CRITICAL') {
      setTimeout(() => showAlertModal(alert), 800);
    }

    Utils.notify(`🚨 ${pattern.title} — ${ip}`, 'error', 5000);
  }

  function renderAlertCard(alert) {
    const panel = document.getElementById('bm-alerts-panel');
    if (!panel) return;

    // Remove empty state
    const empty = panel.querySelector('.empty-state');
    if (empty) empty.remove();

    const color = Utils.severityColor(alert.severity);
    const card  = document.createElement('div');
    card.className = `alert-card ${alert.severity.toLowerCase()}`;
    card.innerHTML = `
      <div class="alert-icon" style="background:${color}18;border:1px solid ${color}30;font-size:20px">${alert.icon}</div>
      <div class="alert-body">
        <div class="alert-title">
          ${alert.title}
          ${Utils.severityBadge(alert.severity)}
          ${MITRE.badge(alert.mitreId)}
        </div>
        <div class="alert-meta">
          <span class="alert-meta-item">🌐 <code class="mono">${alert.ip}</code></span>
          <span class="alert-meta-item">📍 ${alert.geo}</span>
          <span class="alert-meta-item">⚡ <span style="color:${color}">${alert.confidence}%</span></span>
        </div>
        <div class="remediation-box" style="margin-top:8px">
          <div class="rem-title">Remediation</div>
          <span style="font-size:12px">${alert.remediation}</span>
          <div class="rem-cmd">${alert.remCmd.replace(/\{IP\}/g, alert.ip).replace(/\{USER\}/g, alert.user)}</div>
        </div>
        <div class="alert-actions">
          <button class="btn btn-danger btn-sm" onclick="BizMonitorAgent.sendAlerts(${JSON.stringify(alert).replace(/"/g,'&quot;')})">
            📱 Send Alert
          </button>
          <button class="btn btn-ghost btn-sm">🔒 Block IP</button>
        </div>
      </div>
    `;
    panel.prepend(card);

    // Keep max 10 cards
    while (panel.children.length > 10) panel.removeChild(panel.lastChild);
  }

  function addAuditRow(alert) {
    const body = document.getElementById('bm-audit-body');
    if (!body) return;

    const placeholder = body.querySelector('td[colspan]');
    if (placeholder) placeholder.closest('tr').remove();

    const row = document.createElement('tr');
    row.innerHTML = `
      <td class="mono" style="font-size:11px">${alert.time}</td>
      <td style="font-weight:600">${alert.title}</td>
      <td class="mono" style="color:var(--accent-red)">${alert.ip}</td>
      <td style="color:var(--text-muted);font-size:12px">${alert.geo}</td>
      <td>${MITRE.badge(alert.mitreId)}</td>
      <td>${Utils.severityBadge(alert.severity)}</td>
      <td>${Utils.confidenceBar(alert.confidence)}</td>
    `;
    body.prepend(row);
  }

  // ── Alert Modal ─────────────────────────────────────────────
  function showAlertModal(alert) {
    const modal = document.getElementById('bm-alert-modal');
    const content = document.getElementById('bm-modal-content');
    if (!modal || !content) return;

    const cmd = alert.remCmd.replace(/\{IP\}/g, alert.ip).replace(/\{USER\}/g, alert.user);

    content.innerHTML = `
      <div style="margin-bottom:16px">
        ${Utils.severityBadge(alert.severity)}
        <span style="font-size:14px;font-weight:700;margin-left:8px">${alert.title}</span>
      </div>
      ${Utils.confidenceBar(alert.confidence, 'Confidence')}
      <div style="margin:16px 0">${MITRE.card(alert.mitreId)}</div>

      <div class="section-title">WhatsApp Alert (Twilio API)</div>
      <div class="code-output" style="margin-bottom:12px">🚨 *SECURITY ALERT* — ${alert.title}
━━━━━━━━━━━━━━━━━━━━━━━━
📍 Source IP: ${alert.ip} (${alert.geo})
🕐 Time: ${alert.time}
⚡ Confidence: ${alert.confidence}%
🎯 MITRE: ${alert.mitreId} — ${MITRE.get(alert.mitreId).name}
🔧 Remediation: ${cmd}
━━━━━━━━━━━━━━━━━━━━━━━━
Sent by AI Protect Security Agent</div>

      <div class="section-title">Telegram Alert (Bot API)</div>
      <div class="code-output" style="margin-bottom:16px">POST https://api.telegram.org/bot{TOKEN}/sendMessage
{
  "chat_id": "-100123456789",
  "parse_mode": "HTML",
  "text": "🚨 <b>${alert.title}</b>\\n🌐 IP: <code>${alert.ip}</code>\\n📍 ${alert.geo}\\n⚡ ${alert.confidence}% confidence\\n🔧 <code>${cmd}</code>"
}</div>

      <div style="display:flex;gap:10px">
        <button class="btn btn-primary" onclick="BizMonitorAgent.simulateSend('whatsapp','${alert.ip}')">📱 Send WhatsApp</button>
        <button class="btn btn-outline" onclick="BizMonitorAgent.simulateSend('telegram','${alert.ip}')">✈️ Send Telegram</button>
        <button class="btn btn-ghost" onclick="document.getElementById('bm-alert-modal').classList.add('hidden')">Close</button>
      </div>
    `;

    modal.classList.remove('hidden');
  }

  function sendAlerts(alertStr) {
    let alert;
    try { alert = typeof alertStr === 'string' ? JSON.parse(alertStr) : alertStr; } catch { return; }
    showAlertModal(alert);
  }

  function simulateSend(channel, ip) {
    document.getElementById('bm-alert-modal').classList.add('hidden');
    Utils.notify(`✅ Alert sent via ${channel === 'whatsapp' ? 'WhatsApp' : 'Telegram'} for IP ${ip}`, 'success');
  }

  function clearAlerts() {
    const panel = document.getElementById('bm-alerts-panel');
    if (panel) panel.innerHTML = `<div class="empty-state" style="padding:32px">
      <div class="empty-state-icon">🛡️</div>
      <div class="empty-state-text">No threats detected yet</div>
    </div>`;
  }

  function init() {
    // nothing extra needed
  }

  return { render, init, toggleMonitoring, sendAlerts, simulateSend, clearAlerts };
})();
