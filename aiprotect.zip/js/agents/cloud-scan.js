/* ============================================================
   AI PROTECT — AGENT 3: Cloud Misconfiguration Scanner
   ============================================================ */

window.CloudScanAgent = (() => {

  const CLOUD_FINDINGS = {
    aws: [
      {
        id: 'AWS001', severity: 'CRITICAL', service: 'S3', region: 'us-east-1',
        resource: 's3://prod-customer-data-bucket',
        issue: 'Bucket ACL set to PUBLIC — all objects publicly readable',
        description: 'The S3 bucket grants public read access to all objects. Customer PII, contracts, and financial records are exposed to the internet.',
        fix: 'Change bucket ACL to private and enable S3 Block Public Access.',
        fixCmd: 'aws s3api put-bucket-acl --bucket prod-customer-data-bucket --acl private\naws s3api put-public-access-block --bucket prod-customer-data-bucket --public-access-block-configuration "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"',
        jiraTitle: '[CRITICAL] Public S3 Bucket Exposes Customer Data',
        cis: 'CIS AWS 2.1.5'
      },
      {
        id: 'AWS002', severity: 'CRITICAL', service: 'IAM', region: 'global',
        resource: 'arn:aws:iam::123456789:role/LambdaExecutionRole',
        issue: 'IAM role has AdministratorAccess — violates least privilege',
        description: 'Lambda execution role is granted AdministratorAccess (*:*). Any compromise of this Lambda function gives full AWS account control.',
        fix: 'Replace AdministratorAccess with a custom policy granting only required actions.',
        fixCmd: 'aws iam detach-role-policy --role-name LambdaExecutionRole --policy-arn arn:aws:iam::aws:policy/AdministratorAccess\naws iam put-role-policy --role-name LambdaExecutionRole --policy-name least-priv --policy-document file://least-priv.json',
        jiraTitle: '[CRITICAL] IAM Role with AdministratorAccess on Lambda',
        cis: 'CIS AWS 1.16'
      },
      {
        id: 'AWS003', severity: 'CRITICAL', service: 'EC2', region: 'us-east-1',
        resource: 'sg-0a1b2c3d4e5f (default)',
        issue: 'Security group allows 0.0.0.0/0 on port 22 (SSH)',
        description: 'The default security group allows unrestricted inbound SSH from any IP address. This exposes all EC2 instances to brute-force and exploitation.',
        fix: 'Restrict SSH to known admin IP ranges only. Use AWS Session Manager instead.',
        fixCmd: 'aws ec2 revoke-security-group-ingress --group-id sg-0a1b2c3d4e5f --protocol tcp --port 22 --cidr 0.0.0.0/0\naws ec2 authorize-security-group-ingress --group-id sg-0a1b2c3d4e5f --protocol tcp --port 22 --cidr 10.0.0.0/8',
        jiraTitle: '[CRITICAL] Unrestricted SSH in Security Group',
        cis: 'CIS AWS 5.2'
      },
      {
        id: 'AWS004', severity: 'HIGH', service: 'RDS', region: 'us-west-2',
        resource: 'db-prod-mysql-01',
        issue: 'RDS instance storage is not encrypted',
        description: 'Production MySQL RDS instance has encryption at rest disabled. Database snapshots and automated backups are stored unencrypted.',
        fix: 'Enable default encryption with AWS KMS. Create encrypted snapshot and restore.',
        fixCmd: 'aws rds create-db-snapshot --db-instance-identifier db-prod-mysql-01 --db-snapshot-identifier pre-encrypt-snapshot\naws rds copy-db-snapshot --source-db-snapshot-identifier pre-encrypt-snapshot --target-db-snapshot-identifier encrypted-snapshot --kms-key-id alias/aws/rds',
        jiraTitle: '[HIGH] Unencrypted RDS Production Database',
        cis: 'CIS AWS 2.3.1'
      },
      {
        id: 'AWS005', severity: 'HIGH', service: 'EC2', region: 'us-east-1',
        resource: 'sg-deadbeef (app-servers)',
        issue: 'Security group allows 0.0.0.0/0 on port 3306 (MySQL)',
        description: 'MySQL port 3306 is open to the internet. Database can be accessed directly without VPN or bastion host.',
        fix: 'Restrict MySQL access to application server security group only.',
        fixCmd: 'aws ec2 revoke-security-group-ingress --group-id sg-deadbeef --protocol tcp --port 3306 --cidr 0.0.0.0/0',
        jiraTitle: '[HIGH] MySQL Port Exposed to Internet',
        cis: 'CIS AWS 5.6'
      },
      {
        id: 'AWS006', severity: 'HIGH', service: 'CloudTrail', region: 'us-east-1',
        resource: 'arn:aws:cloudtrail:us-east-1:123456789:trail/default',
        issue: 'CloudTrail logging is disabled in 3 regions',
        description: 'CloudTrail is not enabled in eu-west-1, ap-southeast-1, and ap-northeast-1. API activity in these regions is not audited.',
        fix: 'Enable multi-region CloudTrail with log file validation and S3 bucket logging.',
        fixCmd: 'aws cloudtrail create-trail --name global-audit-trail --s3-bucket-name audit-logs-bucket --is-multi-region-trail\naws cloudtrail start-logging --name global-audit-trail',
        jiraTitle: '[HIGH] CloudTrail Disabled in Multiple Regions',
        cis: 'CIS AWS 3.1'
      },
      {
        id: 'AWS007', severity: 'MEDIUM', service: 'S3', region: 'us-east-1',
        resource: 's3://dev-build-artifacts',
        issue: 'S3 bucket versioning disabled — no audit trail for objects',
        description: 'Versioning is disabled on the build artifacts bucket. Malicious artifact replacement would not be detectable.',
        fix: 'Enable S3 versioning and object lock with compliance mode.',
        fixCmd: 'aws s3api put-bucket-versioning --bucket dev-build-artifacts --versioning-configuration Status=Enabled',
        jiraTitle: '[MEDIUM] S3 Versioning Disabled on Artifact Bucket',
        cis: 'CIS AWS 2.1.3'
      },
      {
        id: 'AWS008', severity: 'MEDIUM', service: 'IAM', region: 'global',
        resource: 'arn:aws:iam::123456789:user/ci-deploy-bot',
        issue: 'IAM user with access key older than 90 days',
        description: 'The CI/CD deploy user has an access key that has not been rotated in 187 days. Long-lived credentials increase breach risk.',
        fix: 'Rotate access keys. Migrate to IAM roles for EC2/Lambda instead of long-term keys.',
        fixCmd: 'aws iam create-access-key --user-name ci-deploy-bot\naws iam update-access-key --user-name ci-deploy-bot --access-key-id OLDKEYID --status Inactive',
        jiraTitle: '[MEDIUM] Stale IAM Access Key (187 days)',
        cis: 'CIS AWS 1.14'
      },
    ],

    azure: [
      {
        id: 'AZ001', severity: 'CRITICAL', service: 'Blob Storage', region: 'East US',
        resource: 'storageaccount.blob.core.windows.net/public-container',
        issue: 'Blob container has Public access level set to "Blob"',
        description: 'The blob container allows anonymous read access to all blobs. Any authenticated URL leakage exposes sensitive data.',
        fix: 'Set container public access to "Private". Enable Azure Defender for Storage.',
        fixCmd: 'az storage container set-permission --name public-container --account-name storageaccount --public-access off',
        jiraTitle: '[CRITICAL] Azure Blob Container with Public Access',
        cis: 'CIS Azure 3.5'
      },
      {
        id: 'AZ002', severity: 'CRITICAL', service: 'Network Security Group', region: 'East US',
        resource: 'nsg-prod-app/inbound-rules',
        issue: 'NSG allows RDP (port 3389) from Internet (0.0.0.0/0)',
        description: 'RDP is exposed to the entire internet. This is a top attack vector for ransomware groups.',
        fix: 'Remove inbound RDP rule from internet. Use Azure Bastion or Just-in-Time VM access.',
        fixCmd: 'az network nsg rule delete --resource-group prod-rg --nsg-name nsg-prod-app --name allow-rdp-internet',
        jiraTitle: '[CRITICAL] RDP Exposed to Internet via NSG',
        cis: 'CIS Azure 6.1'
      },
      {
        id: 'AZ003', severity: 'HIGH', service: 'SQL Database', region: 'West Europe',
        resource: 'prod-sqlserver/prod-database',
        issue: 'Transparent Data Encryption (TDE) is disabled',
        description: 'Azure SQL Database TDE is disabled. Database files stored on disk are unencrypted.',
        fix: 'Enable Transparent Data Encryption with Customer Managed Key (CMK) using Azure Key Vault.',
        fixCmd: 'az sql db tde set --resource-group prod-rg --server prod-sqlserver --database prod-database --status Enabled',
        jiraTitle: '[HIGH] SQL Database TDE Disabled',
        cis: 'CIS Azure 4.1.1'
      },
      {
        id: 'AZ004', severity: 'MEDIUM', service: 'Active Directory', region: 'global',
        resource: 'tenant: contoso.onmicrosoft.com',
        issue: 'MFA not enforced for all privileged users (3 Global Admins)',
        description: '3 Global Administrator accounts do not have MFA enforced. Single-factor admin accounts are primary targets for account takeover.',
        fix: 'Enable Conditional Access policy requiring MFA for all privileged roles.',
        fixCmd: 'Enable via Azure Portal > Azure AD > Security > Conditional Access > New Policy > Require MFA for Global Admins',
        jiraTitle: '[MEDIUM] MFA Not Enforced for Global Admins',
        cis: 'CIS Azure 1.1'
      },
    ],

    gcp: [
      {
        id: 'GCP001', severity: 'CRITICAL', service: 'Cloud Storage', region: 'us-central1',
        resource: 'gs://prod-ml-training-data',
        issue: 'Bucket is publicly accessible (allUsers has Storage Object Viewer)',
        description: 'The GCS bucket grants allUsers the Storage Object Viewer role. All training data and models are publicly downloadable.',
        fix: 'Remove allUsers and allAuthenticatedUsers IAM bindings from the bucket.',
        fixCmd: 'gcloud storage buckets remove-iam-policy-binding gs://prod-ml-training-data --member=allUsers --role=roles/storage.objectViewer',
        jiraTitle: '[CRITICAL] GCS Bucket Publicly Accessible',
        cis: 'CIS GCP 5.1'
      },
      {
        id: 'GCP002', severity: 'HIGH', service: 'Compute Engine', region: 'us-central1',
        resource: 'instance-1 (default network)',
        issue: 'Firewall rule allows SSH (22) from 0.0.0.0/0',
        description: 'Default firewall rule allows SSH access from any IP. All compute instances in this VPC are exposed.',
        fix: 'Delete default-allow-ssh rule. Use Identity-Aware Proxy (IAP) for SSH access.',
        fixCmd: 'gcloud compute firewall-rules delete default-allow-ssh\ngcloud compute firewall-rules create allow-ssh-iap --allow tcp:22 --source-ranges 35.235.240.0/20',
        jiraTitle: '[HIGH] SSH Firewall Rule Open to Internet',
        cis: 'CIS GCP 3.6'
      },
      {
        id: 'GCP003', severity: 'HIGH', service: 'IAM', region: 'global',
        resource: 'service-account@project.iam.gserviceaccount.com',
        issue: 'Service account has Editor role at project level',
        description: 'A service account used by Cloud Functions has the Editor primitive role, granting write access to all GCP services.',
        fix: 'Replace Editor role with specific predefined roles following least privilege.',
        fixCmd: 'gcloud projects remove-iam-policy-binding PROJECT_ID --member=serviceAccount:sa@project.iam.gserviceaccount.com --role=roles/editor',
        jiraTitle: '[HIGH] Service Account with Editor Role',
        cis: 'CIS GCP 1.5'
      },
      {
        id: 'GCP004', severity: 'MEDIUM', service: 'Cloud SQL', region: 'us-central1',
        resource: 'pg-prod-instance',
        issue: 'Cloud SQL instance has a public IP address',
        description: 'The PostgreSQL instance has a public IP assigned and SSL enforcement is not enabled, exposing it to unauthenticated connection attempts.',
        fix: 'Remove public IP. Use Cloud SQL Auth Proxy. Enable require_ssl.',
        fixCmd: 'gcloud sql instances patch pg-prod-instance --no-assign-ip --require-ssl',
        jiraTitle: '[MEDIUM] Cloud SQL with Public IP and No SSL',
        cis: 'CIS GCP 6.2'
      },
    ]
  };

  let currentFindings = [];
  let currentCloud = 'aws';
  let scanning = false;

  // ── Render ─────────────────────────────────────────────────
  function render() {
    return `
    <div class="agent-hero">
      <div class="agent-hero-left">
        <div class="agent-hero-icon" style="background:linear-gradient(135deg,#0066ff,#0044cc)">☁️</div>
        <div>
          <div class="agent-hero-title">Cloud Misconfiguration Scanner</div>
          <div class="agent-hero-sub">AWS · Azure · GCP · Terraform/CloudFormation · Severity-ranked findings · Auto-remediation</div>
        </div>
      </div>
      <div class="agent-hero-right">
        <span class="pill">CIS Benchmarks</span>
        <span class="pill">AWS Well-Architected</span>
      </div>
    </div>

    <!-- Cloud Provider Tabs -->
    <div class="tabs" id="cloud-tabs">
      <button class="tab-btn active" onclick="CloudScanAgent.selectCloud('aws',this)">☁️ AWS</button>
      <button class="tab-btn" onclick="CloudScanAgent.selectCloud('azure',this)">🔷 Azure</button>
      <button class="tab-btn" onclick="CloudScanAgent.selectCloud('gcp',this)">🔴 GCP</button>
      <button class="tab-btn" onclick="CloudScanAgent.selectCloud('terraform',this)">🏗️ Terraform</button>
    </div>

    <!-- Terraform Upload Panel -->
    <div id="cloud-terraform-panel" style="display:none;margin-bottom:16px">
      <div class="upload-zone" style="padding:32px" onclick="document.getElementById('cs-tf-input').click()">
        <span class="upload-icon" style="font-size:36px">🏗️</span>
        <div class="upload-title">Upload Terraform/CloudFormation Template</div>
        <div class="upload-sub">Static analysis of IaC configurations</div>
        <div class="upload-hint">.tf · .yaml · .json · .template</div>
      </div>
      <input type="file" id="cs-tf-input" accept=".tf,.yaml,.yml,.json,.template" style="display:none">
    </div>

    <!-- Scan Controls -->
    <div class="card" style="margin-bottom:16px;background:rgba(0,102,255,0.04);border-color:rgba(0,102,255,0.15)" id="cloud-controls">
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
        <div>
          <div style="font-size:14px;font-weight:700;margin-bottom:4px">
            <span id="cs-cloud-name">Amazon Web Services</span> — Read-Only Scan
          </div>
          <div style="font-size:12px;color:var(--text-muted)">
            Uses read-only credentials • No changes will be made to your infrastructure
          </div>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <button class="btn btn-primary" onclick="CloudScanAgent.runScan()" id="cs-scan-btn">
            🔍 Start Scan
          </button>
          <button class="btn btn-ghost" onclick="CloudScanAgent.exportCSV()" id="cs-export-btn" style="display:none">
            ⬇ Export CSV
          </button>
          <button class="btn btn-ghost" onclick="CloudScanAgent.openJira()" id="cs-jira-btn" style="display:none">
            🎫 Create Jira Tickets
          </button>
        </div>
      </div>
    </div>

    <!-- Scan Progress -->
    <div id="cs-scan-state" style="display:none">
      <div class="scan-container" style="padding:32px">
        <div class="scan-ring-wrap">
          <div class="scan-ring scan-ring-1"></div>
          <div class="scan-ring scan-ring-2"></div>
          <div class="scan-ring scan-ring-3"></div>
          <div class="scan-pulse"></div>
          <div class="scan-inner">☁️</div>
        </div>
        <div class="scan-status" id="cs-scan-status">Connecting to cloud provider…</div>
        <div class="scan-detail" id="cs-scan-detail"></div>
        <div class="scan-progress-bar"><div class="scan-progress-fill" id="cs-progress-fill"></div></div>
      </div>
    </div>

    <!-- Results -->
    <div id="cs-result-state" style="display:none"></div>

    <!-- Jira Modal -->
    <div class="modal-overlay hidden" id="cs-jira-modal">
      <div class="modal-box" style="max-width:640px">
        <div class="modal-header">
          <div class="modal-title">🎫 Create Jira / GitHub Issues</div>
          <button class="modal-close" onclick="document.getElementById('cs-jira-modal').classList.add('hidden')">✕</button>
        </div>
        <div id="cs-jira-content"></div>
      </div>
    </div>

    <!-- Fix Modal -->
    <div class="modal-overlay hidden" id="cs-fix-modal">
      <div class="modal-box">
        <div class="modal-header">
          <div class="modal-title">🔧 Remediation Guide</div>
          <button class="modal-close" onclick="document.getElementById('cs-fix-modal').classList.add('hidden')">✕</button>
        </div>
        <div id="cs-fix-content"></div>
      </div>
    </div>
    `;
  }

  function selectCloud(cloud, btn) {
    currentCloud = cloud;
    document.querySelectorAll('#cloud-tabs .tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const cloudNames = { aws: 'Amazon Web Services', azure: 'Microsoft Azure', gcp: 'Google Cloud Platform', terraform: 'Infrastructure as Code (Terraform)' };
    const nameEl = document.getElementById('cs-cloud-name');
    if (nameEl) nameEl.textContent = cloudNames[cloud] || cloud.toUpperCase();

    const tfPanel = document.getElementById('cloud-terraform-panel');
    if (tfPanel) tfPanel.style.display = cloud === 'terraform' ? 'block' : 'none';

    // Reset results
    const resultEl = document.getElementById('cs-result-state');
    if (resultEl) { resultEl.style.display = 'none'; resultEl.innerHTML = ''; }
    ['cs-export-btn','cs-jira-btn'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.display = 'none';
    });
  }

  async function runScan() {
    const btn = document.getElementById('cs-scan-btn');
    if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Scanning…'; }

    document.getElementById('cs-scan-state').style.display  = 'block';
    document.getElementById('cs-result-state').style.display = 'none';

    const cloud = currentCloud === 'terraform' ? 'aws' : currentCloud;
    const checkList = {
      aws:   ['IAM policies', 'S3 bucket ACLs', 'Security groups', 'RDS encryption', 'CloudTrail', 'VPC flow logs', 'KMS key rotation'],
      azure: ['NSG rules', 'Blob storage access', 'SQL TDE', 'Key Vault policies', 'Azure AD MFA', 'Disk encryption'],
      gcp:   ['GCS bucket IAM', 'Firewall rules', 'Service accounts', 'Cloud SQL', 'GKE config', 'Audit logging'],
    };

    const checks = checkList[cloud] || checkList.aws;
    const statusEl  = document.getElementById('cs-scan-status');
    const detailEl  = document.getElementById('cs-scan-detail');
    const progressEl= document.getElementById('cs-progress-fill');

    for (let i = 0; i < checks.length; i++) {
      if (statusEl)   statusEl.textContent  = `Checking ${checks[i]}…`;
      if (detailEl)   detailEl.textContent  = `Scanning ${Utils.randomBetween(10,80)} resources…`;
      if (progressEl) progressEl.style.width = `${Math.round((i+1)/checks.length*100)}%`;
      await Utils.sleep(Utils.randomBetween(400, 700));
    }

    if (statusEl) statusEl.textContent = 'Analysis complete!';
    if (progressEl) progressEl.style.width = '100%';
    await Utils.sleep(500);

    showResults(cloud);
    if (btn) { btn.disabled = false; btn.innerHTML = '🔍 Start Scan'; }
  }

  function showResults(cloud) {
    document.getElementById('cs-scan-state').style.display   = 'none';
    document.getElementById('cs-result-state').style.display = 'block';

    const findings = CLOUD_FINDINGS[cloud] || [];
    currentFindings = findings;

    const counts = {
      CRITICAL: findings.filter(f => f.severity === 'CRITICAL').length,
      HIGH:     findings.filter(f => f.severity === 'HIGH').length,
      MEDIUM:   findings.filter(f => f.severity === 'MEDIUM').length,
      LOW:      findings.filter(f => f.severity === 'LOW').length,
    };

    ['cs-export-btn','cs-jira-btn'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.display = '';
    });

    const html = `
      ${ReportEngine.reportHeader({
        agentName: 'Cloud Misconfiguration Scanner',
        target: cloud.toUpperCase() + ' Infrastructure',
        scanTime: Utils.now(),
        riskScore: counts.CRITICAL * 28 + counts.HIGH * 16 + counts.MEDIUM * 8,
        riskLabel: counts.CRITICAL > 0 ? 'CRITICAL RISK' : 'HIGH RISK'
      })}

      <div class="spacer">${ReportEngine.summaryTable(counts, 'Misconfiguration Summary')}</div>

      <div class="section-title">Findings</div>
      ${ReportEngine.cloudFindingsTable(findings)}

      <div style="margin-top:20px;display:flex;flex-direction:column;gap:12px">
        ${findings.map(f => renderFindingCard(f)).join('')}
      </div>
    `;

    document.getElementById('cs-result-state').innerHTML = html;
    Utils.animateProgressBars();

    // Bind view fix buttons
    setTimeout(() => {
      document.querySelectorAll('.view-fix-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const finding = findings.find(f => f.id === btn.dataset.id);
          if (finding) showFixModal(finding);
        });
      });
    }, 100);

    Utils.notify(`Cloud scan complete — ${counts.CRITICAL} critical misconfigurations found`, 'warning');
  }

  function renderFindingCard(f) {
    const color = Utils.severityColor(f.severity);
    return `<div class="card" style="border-left:3px solid ${color}40" id="cloud-${f.id}">
      <div class="card-header">
        <div>
          <div class="card-title">${Utils.severityBadge(f.severity)} ${f.resource}</div>
          <div class="card-subtitle">
            <span class="tag">${f.service}</span>
            <span style="margin-left:6px;font-size:11px;color:var(--text-muted)">📍 ${f.region}</span>
            ${f.cis ? `<span class="tag" style="margin-left:4px">${f.cis}</span>` : ''}
          </div>
        </div>
      </div>
      <p style="font-size:13px;color:var(--accent-red);font-weight:600;margin-bottom:8px">⚠ ${f.issue}</p>
      <p style="font-size:13px;color:var(--text-secondary);margin-bottom:12px">${f.description}</p>
      <div class="remediation-box">
        <div class="rem-title">✅ Recommended Fix</div>
        <p style="font-size:12px;margin-bottom:8px">${f.fix}</p>
        <div class="rem-cmd" style="white-space:pre;overflow-x:auto">${f.fixCmd}</div>
      </div>
    </div>`;
  }

  function showFixModal(finding) {
    const modal   = document.getElementById('cs-fix-modal');
    const content = document.getElementById('cs-fix-content');
    if (!modal || !content) return;

    content.innerHTML = `
      <div style="margin-bottom:12px">
        ${Utils.severityBadge(finding.severity)}
        <span style="font-size:14px;font-weight:700;margin-left:8px">${finding.resource}</span>
      </div>
      <p style="color:var(--accent-red);font-weight:600;margin-bottom:8px">⚠ ${finding.issue}</p>
      <p style="font-size:13px;color:var(--text-secondary);margin-bottom:16px">${finding.description}</p>
      <div class="remediation-box" style="margin-bottom:16px">
        <div class="rem-title">Fix Command</div>
        <div class="rem-cmd" style="white-space:pre;overflow-x:auto">${finding.fixCmd}</div>
      </div>
      <button class="btn btn-ghost btn-sm" onclick="navigator.clipboard.writeText('${finding.fixCmd.replace(/'/g,"\\'")}').then(()=>Utils.notify('Copied!','success'))">
        📋 Copy Fix Command
      </button>
    `;
    modal.classList.remove('hidden');
  }

  function openJira() {
    const modal   = document.getElementById('cs-jira-modal');
    const content = document.getElementById('cs-jira-content');
    if (!modal || !content) return;

    const criticals = currentFindings.filter(f => f.severity === 'CRITICAL' || f.severity === 'HIGH');
    content.innerHTML = `
      <p style="font-size:13px;color:var(--text-secondary);margin-bottom:16px">
        ${criticals.length} Critical/High findings will be created as Jira tickets:
      </p>
      ${criticals.map((f, i) => `
        <div class="card" style="margin-bottom:8px;padding:12px;animation-delay:${i*50}ms">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
            ${Utils.severityBadge(f.severity)}
            <span style="font-size:13px;font-weight:600">${f.jiraTitle}</span>
          </div>
          <div style="font-size:11px;color:var(--text-muted)">
            Labels: cloud-security, ${f.service.toLowerCase()}, ${currentCloud} | Priority: ${f.severity}
          </div>
        </div>
      `).join('')}
      <div style="display:flex;gap:10px;margin-top:16px">
        <button class="btn btn-primary" onclick="CloudScanAgent.simulateJira()">🎫 Create Jira Tickets</button>
        <button class="btn btn-outline" onclick="CloudScanAgent.simulateGitHub()">🐙 Create GitHub Issues</button>
        <button class="btn btn-ghost" onclick="document.getElementById('cs-jira-modal').classList.add('hidden')">Cancel</button>
      </div>
    `;
    modal.classList.remove('hidden');
  }

  function simulateJira() {
    document.getElementById('cs-jira-modal').classList.add('hidden');
    Utils.notify(`✅ ${currentFindings.filter(f=>['CRITICAL','HIGH'].includes(f.severity)).length} Jira tickets created successfully`, 'success');
  }

  function simulateGitHub() {
    document.getElementById('cs-jira-modal').classList.add('hidden');
    Utils.notify(`✅ GitHub Issues created with security labels`, 'success');
  }

  function exportCSV() {
    if (!currentFindings.length) { Utils.notify('Run a scan first', 'warning'); return; }
    ReportEngine.buildCSV(currentFindings, ['id','severity','service','region','resource','issue','description','fix','cis']);
    Utils.notify('CSV report downloaded', 'success');
  }

  function init() {}

  return { render, init, selectCloud, runScan, openJira, simulateJira, simulateGitHub, exportCSV };
})();
