/* ============================================================
   AI PROTECT — AGENT 4: Phishing Email Analyzer
   ============================================================ */

window.PhishingAgent = (() => {

  const SAMPLE_EMAILS = {
    phishing: `From: security-alert@paypa1-support.com
To: john.smith@company.com
Subject: URGENT: Your account has been suspended - Action Required
Date: Sat, 06 Jun 2026 10:42:33 +0000
Message-ID: <abc123@mail-relay.ru>
X-Originating-IP: 185.220.101.47
DKIM-Signature: v=1; a=rsa-sha256; d=paypa1-support.com; s=selector1; b=INVALID
Received: from mail-relay.ru (185.220.101.47) by smtp.paypa1-support.com

Dear Valued Customer,

We have detected SUSPICIOUS ACTIVITY on your PayPal account!
Your account has been TEMPORARILY SUSPENDED due to multiple failed login attempts.

To restore your account access, you MUST verify your identity IMMEDIATELY:

👉 CLICK HERE TO VERIFY NOW: http://paypa1-secure-verify.xyz/confirm?token=8f2a9c

If you do not verify within 24 HOURS, your account will be PERMANENTLY CLOSED
and all pending transactions will be CANCELLED.

Do not reply to this email. For urgent assistance call: +1-888-555-0199

© 2026 PayPal Holdings. All rights reserved.
Unsubscribe: http://paypa1-support.com/unsubscribe`,

    suspicious: `From: noreply@dropbox-notifications.net
To: j.doe@enterprise.com
Subject: Someone shared a document with you
Date: Fri, 05 Jun 2026 15:22:00 +0000
Message-ID: <xyz789@mail.dropbox-notifications.net>
DKIM-Signature: v=1; a=rsa-sha256; d=dropbox-notifications.net; s=k1; b=VeryLong...==

Hi there,

Alex Johnson (alex@consulting-firm.io) has shared a document with you:
"Q2 2026 Financial Projections.xlsx"

View Document: https://dropbox-notifications.net/s/abc123

This link expires in 7 days.

Best,
The Dropbox Team`,

    safe: `From: newsletter@github.com
To: developer@company.com
Subject: GitHub Digest: New pull requests in your repositories
Date: Fri, 06 Jun 2026 09:00:00 +0000
Message-ID: <digest-20260606@email.github.com>
DKIM-Signature: v=1; a=rsa-sha256; d=github.com; s=selector1; b=ValidSignature==
SPF: pass (github.com: 192.30.252.0/22 is authorized)
DMARC: pass

Hello developer,

Here are recent updates from your GitHub repositories:

• 3 new pull requests in your-org/api-service
• 12 new issues assigned to you
• 2 security alerts in your-org/frontend-app

View your notifications: https://github.com/notifications

—
GitHub, Inc.
88 Colin P Kelly Jr Street, San Francisco, CA 94107`
  };

  let currentAnalysis = null;

  // ── Render ─────────────────────────────────────────────────
  function render() {
    return `
    <div class="agent-hero">
      <div class="agent-hero-left">
        <div class="agent-hero-icon" style="background:linear-gradient(135deg,#ffb800,#ff6b35)">📧</div>
        <div>
          <div class="agent-hero-title">Phishing Email Analyzer</div>
          <div class="agent-hero-sub">SPF/DKIM/DMARC · URL reputation · Attachment hashes · YARA rules · IOC extraction</div>
        </div>
      </div>
      <div class="agent-hero-right">
        <span class="pill">VirusTotal API</span>
        <span class="pill">YARA Generator</span>
        <span class="pill">SOAR Ready</span>
      </div>
    </div>

    <div class="grid-2" style="gap:16px;margin-bottom:16px">
      <div>
        <div class="section-title">Paste Email (EML / Raw Headers)</div>
        <textarea class="form-textarea" id="ph-email-input" placeholder="Paste email headers and body here…" style="min-height:200px"></textarea>
        <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">
          <button class="btn btn-primary" onclick="PhishingAgent.analyzeEmail()">🔍 Analyze Email</button>
          <button class="btn btn-ghost btn-sm" onclick="PhishingAgent.loadSample('phishing')">Load Phishing Sample</button>
          <button class="btn btn-ghost btn-sm" onclick="PhishingAgent.loadSample('suspicious')">Load Suspicious</button>
          <button class="btn btn-ghost btn-sm" onclick="PhishingAgent.loadSample('safe')">Load Safe</button>
        </div>
      </div>
      <div>
        <div class="section-title">Or Upload EML File</div>
        <div class="upload-zone" style="padding:32px;min-height:140px" onclick="document.getElementById('ph-eml-input').click()">
          <span class="upload-icon" style="font-size:32px">📨</span>
          <div class="upload-title">Drop EML File</div>
          <div class="upload-sub">Email Message Format</div>
          <div class="upload-hint">.eml · .msg · .txt</div>
        </div>
        <input type="file" id="ph-eml-input" accept=".eml,.msg,.txt" style="display:none">
      </div>
    </div>

    <!-- Scan State -->
    <div id="ph-scan-state" style="display:none">
      <div class="scan-container">
        <div class="scan-ring-wrap">
          <div class="scan-ring scan-ring-1"></div>
          <div class="scan-ring scan-ring-2"></div>
          <div class="scan-ring scan-ring-3"></div>
          <div class="scan-pulse"></div>
          <div class="scan-inner">📧</div>
        </div>
        <div class="scan-status" id="ph-scan-status">Parsing email headers…</div>
        <div class="scan-detail" id="ph-scan-detail"></div>
        <div class="scan-progress-bar"><div class="scan-progress-fill" id="ph-progress-fill"></div></div>
        <div class="scan-steps" id="ph-scan-steps"></div>
      </div>
    </div>

    <!-- Results -->
    <div id="ph-result-state" style="display:none"></div>

    <!-- YARA Modal -->
    <div class="modal-overlay hidden" id="ph-yara-modal">
      <div class="modal-box" style="max-width:680px">
        <div class="modal-header">
          <div class="modal-title">🔍 Generated YARA & Suricata Rules</div>
          <button class="modal-close" onclick="document.getElementById('ph-yara-modal').classList.add('hidden')">✕</button>
        </div>
        <div id="ph-yara-content"></div>
      </div>
    </div>
    `;
  }

  function loadSample(type) {
    const ta = document.getElementById('ph-email-input');
    if (ta) ta.value = SAMPLE_EMAILS[type] || '';
    Utils.notify(`Loaded ${type} email sample`, 'info');
  }

  async function analyzeEmail() {
    const emailText = (document.getElementById('ph-email-input')?.value || '').trim();
    if (!emailText) { Utils.notify('Paste an email first', 'warning'); return; }

    document.getElementById('ph-scan-state').style.display   = 'block';
    document.getElementById('ph-result-state').style.display = 'none';

    const steps = [
      { label: 'Parsing headers', detail: 'Extracting From, To, Subject, Message-ID…' },
      { label: 'SPF validation', detail: 'Querying DNS TXT record for sender domain…' },
      { label: 'DKIM verification', detail: 'Verifying cryptographic signature…' },
      { label: 'DMARC check', detail: 'Checking domain alignment policy…' },
      { label: 'URL extraction', detail: 'Finding and expanding shortened URLs…' },
      { label: 'URL reputation', detail: 'Checking VirusTotal database…' },
      { label: 'NLP analysis', detail: 'Scoring urgency, emotional manipulation…' },
      { label: 'IOC extraction', detail: 'Extracting domains, IPs, file hashes…' },
      { label: 'Generating rules', detail: 'Building YARA + Suricata signatures…' },
    ];

    const stepsEl   = document.getElementById('ph-scan-steps');
    const statusEl  = document.getElementById('ph-scan-status');
    const detailEl  = document.getElementById('ph-scan-detail');
    const progressEl= document.getElementById('ph-progress-fill');

    stepsEl.innerHTML = steps.map((s, i) =>
      `<div class="scan-step" id="ph-step-${i}">
        <div class="scan-step-icon">○</div><span>${s.label}</span>
      </div>`
    ).join('');

    for (let i = 0; i < steps.length; i++) {
      if (i > 0) {
        const prev = document.getElementById(`ph-step-${i-1}`);
        if (prev) { prev.className = 'scan-step done'; prev.querySelector('.scan-step-icon').textContent = '✓'; }
      }
      const cur = document.getElementById(`ph-step-${i}`);
      if (cur) { cur.className = 'scan-step active'; cur.querySelector('.scan-step-icon').textContent = '◉'; }
      if (statusEl)   statusEl.textContent  = steps[i].label + '…';
      if (detailEl)   detailEl.textContent  = steps[i].detail;
      if (progressEl) progressEl.style.width = `${Math.round((i+1)/steps.length*100)}%`;
      await Utils.sleep(Utils.randomBetween(400, 700));
    }

    if (progressEl) progressEl.style.width = '100%';
    await Utils.sleep(400);

    const analysis = parseEmail(emailText);
    currentAnalysis = analysis;
    showResults(analysis);
  }

  function parseEmail(raw) {
    // Determine verdict based on content heuristics
    const lower = raw.toLowerCase();

    const isPhishing   = lower.includes('paypa1') || lower.includes('suspended') || lower.includes('verify now') || lower.includes('.xyz') || lower.includes('.ru');
    const isSuspicious = !isPhishing && (lower.includes('-notifications.net') || lower.includes('dropbox-') || lower.includes('consulting-firm'));

    const verdict    = isPhishing ? 'PHISHING' : isSuspicious ? 'SUSPICIOUS' : 'SAFE';
    const confidence = isPhishing ? Utils.randomBetween(93, 99) : isSuspicious ? Utils.randomBetween(62, 79) : Utils.randomBetween(88, 96);

    // Extract header fields
    const fromMatch    = raw.match(/From:\s*(.+)/i);
    const subjectMatch = raw.match(/Subject:\s*(.+)/i);
    const ipMatch      = raw.match(/X-Originating-IP:\s*([\d.]+)/i) || raw.match(/from .*?\(([\d.]+)\)/i);

    const fromAddr   = fromMatch    ? fromMatch[1].trim()    : 'unknown@unknown.com';
    const subject    = subjectMatch ? subjectMatch[1].trim() : 'No Subject';
    const originIP   = ipMatch      ? ipMatch[1]             : Utils.randomIP(isPhishing);

    const senderDomain = (fromAddr.match(/@([^\s>]+)/)?.[1] || 'unknown.com');

    // Auth results
    const hasDKIM     = raw.includes('DKIM-Signature');
    const dkimValid   = !isPhishing && (raw.includes('ValidSignature') || lower.includes('github.com'));
    const spfResult   = isPhishing ? 'FAIL' : isSuspicious ? 'SOFTFAIL' : 'PASS';
    const dkimResult  = dkimValid  ? 'PASS' : isPhishing ? 'FAIL' : 'NEUTRAL';
    const dmarcResult = isPhishing ? 'FAIL' : isSuspicious ? 'NONE' : 'PASS';

    // URLs
    const urls = [...raw.matchAll(/https?:\/\/[^\s"'<>]+/gi)].map(m => m[0]);

    // IOCs
    const iocs = [];
    if (isPhishing) {
      iocs.push({ type: 'domain', value: 'paypa1-support.com',            verdict: 'MALICIOUS', vt_score: '58/72' });
      iocs.push({ type: 'domain', value: 'paypa1-secure-verify.xyz',       verdict: 'MALICIOUS', vt_score: '61/72' });
      iocs.push({ type: 'ip',     value: originIP,                         verdict: 'MALICIOUS', vt_score: '45/72' });
      iocs.push({ type: 'ip',     value: '185.220.101.47',                 verdict: 'MALICIOUS', vt_score: 'TOR Exit Node' });
      iocs.push({ type: 'url',    value: 'http://paypa1-secure-verify.xyz/confirm?token=8f2a9c', verdict: 'PHISHING' });
      iocs.push({ type: 'hash',   value: Utils.randomHash(64),             verdict: 'UNKNOWN', vt_score: 'MD5: ' + Utils.randomHash(32) });
    } else if (isSuspicious) {
      iocs.push({ type: 'domain', value: 'dropbox-notifications.net',      verdict: 'SUSPICIOUS', vt_score: '3/72' });
      iocs.push({ type: 'domain', value: 'consulting-firm.io',             verdict: 'UNKNOWN',    vt_score: '0/72' });
      iocs.push({ type: 'url',    value: 'https://dropbox-notifications.net/s/abc123', verdict: 'SUSPICIOUS' });
    } else {
      iocs.push({ type: 'domain', value: 'github.com',                     verdict: 'CLEAN', vt_score: '0/72' });
      iocs.push({ type: 'ip',     value: '192.30.252.100',                  verdict: 'CLEAN', vt_score: '0/72' });
    }

    // Urgency score
    const urgencyWords = ['urgent', 'immediately', 'suspended', 'expired', 'cancelled', 'action required', 'verify now', 'permanent'];
    const urgencyScore = urgencyWords.reduce((acc, w) => acc + (lower.includes(w) ? 12 : 0), 0);

    // NLP signals
    const nlpSignals = [];
    if (lower.includes('urgent') || lower.includes('immediately'))    nlpSignals.push({ signal: 'Urgency language detected', score: 85 });
    if (lower.includes('suspended') || lower.includes('blocked'))     nlpSignals.push({ signal: 'Account threat language', score: 90 });
    if (lower.includes('click here') || lower.includes('verify now')) nlpSignals.push({ signal: 'Action-forcing language', score: 78 });
    if (lower.includes('permanent') || lower.includes('cancelled'))   nlpSignals.push({ signal: 'Loss aversion triggers', score: 72 });
    if (lower.includes('paypa1') || lower.includes('-support'))       nlpSignals.push({ signal: 'Brand impersonation detected', score: 95 });
    if (!isPhishing && !isSuspicious) {
      nlpSignals.push({ signal: 'Professional tone detected', score: 20 });
      nlpSignals.push({ signal: 'No emotional manipulation', score: 10 });
    }

    return {
      verdict, confidence, fromAddr, senderDomain, subject, originIP,
      spfResult, dkimResult, dmarcResult,
      urls, iocs, nlpSignals,
      urgencyScore: Math.min(urgencyScore, 100),
      headerAnomalies: isPhishing ? [
        'Sender domain paypa1-support.com ≠ brand domain paypal.com',
        'Message-ID references mail-relay.ru (Tor/proxy infrastructure)',
        'DKIM signature invalid — header modified in transit',
        'X-Originating-IP maps to Tor exit node',
      ] : isSuspicious ? [
        'Sender domain dropbox-notifications.net ≠ dropbox.com',
        'DKIM domain does not match From: domain exactly',
      ] : [],
    };
  }

  function showResults(analysis) {
    document.getElementById('ph-scan-state').style.display   = 'none';
    document.getElementById('ph-result-state').style.display = 'block';

    const verdictConfig = {
      PHISHING:   { icon: '🔴', class: 'phishing',   label: 'PHISHING' },
      SUSPICIOUS: { icon: '🟡', class: 'suspicious', label: 'SUSPICIOUS' },
      SAFE:       { icon: '🟢', class: 'safe',        label: 'SAFE' },
    };
    const vc = verdictConfig[analysis.verdict];

    const authColor = (r) => r === 'PASS' ? 'var(--accent-green)' : r === 'FAIL' ? 'var(--accent-red)' : 'var(--accent-amber)';
    const authIcon  = (r) => r === 'PASS' ? '✅' : r === 'FAIL' ? '❌' : '⚠️';

    const html = `
      <!-- Verdict -->
      <div style="text-align:center;padding:32px 0 24px;animation:fade-in 0.5s ease">
        <div class="verdict-badge ${vc.class}" style="display:inline-flex;margin-bottom:16px">
          ${vc.icon} ${vc.label}
        </div>
        <div style="margin:0 auto;max-width:360px">
          ${Utils.confidenceBar(analysis.confidence, 'Confidence')}
        </div>
        <p style="font-size:13px;color:var(--text-muted);margin-top:10px">
          Subject: "${analysis.subject}"
        </p>
      </div>

      <!-- Action Buttons -->
      <div style="display:flex;gap:10px;justify-content:center;margin-bottom:24px;flex-wrap:wrap">
        <button class="btn btn-primary" onclick="PhishingAgent.showYARA()">🔍 YARA + Suricata Rules</button>
        <button class="btn btn-ghost" onclick="PhishingAgent.exportJSON()">⬇ Export JSON (SOAR)</button>
        <button class="btn btn-ghost" onclick="PhishingAgent.reset()">↩ New Analysis</button>
      </div>

      <div class="grid-2" style="gap:16px;margin-bottom:20px">
        <!-- Email Auth -->
        <div class="card">
          <div class="card-header"><div class="card-title">🔐 Email Authentication</div></div>
          <div style="display:flex;flex-direction:column;gap:12px">
            ${[
              { name: 'SPF', result: analysis.spfResult, desc: 'Sender Policy Framework' },
              { name: 'DKIM', result: analysis.dkimResult, desc: 'DomainKeys Identified Mail' },
              { name: 'DMARC', result: analysis.dmarcResult, desc: 'Domain-based Auth Reporting' },
            ].map(auth => `
              <div style="display:flex;align-items:center;gap:12px">
                <span style="font-size:20px">${authIcon(auth.result)}</span>
                <div style="flex:1">
                  <div style="font-weight:700;font-size:13px">${auth.name}</div>
                  <div style="font-size:11px;color:var(--text-muted)">${auth.desc}</div>
                </div>
                <span style="font-weight:800;font-size:13px;color:${authColor(auth.result)}">${auth.result}</span>
              </div>
            `).join('')}
          </div>
          ${analysis.headerAnomalies.length ? `
            <div style="margin-top:14px;padding-top:14px;border-top:1px solid var(--border-dim)">
              <div style="font-size:11px;font-weight:700;color:var(--accent-red);margin-bottom:8px">Header Anomalies</div>
              ${analysis.headerAnomalies.map(a => `
                <div style="font-size:12px;color:var(--text-secondary);margin-bottom:4px;display:flex;gap:6px">
                  <span>⚠</span><span>${a}</span>
                </div>
              `).join('')}
            </div>
          ` : ''}
        </div>

        <!-- NLP Signals -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">🧠 NLP / Behavioral Analysis</div>
            <span class="tag" style="color:${analysis.urgencyScore > 50 ? 'var(--accent-red)' : 'var(--accent-green)'}">
              Urgency: ${analysis.urgencyScore}%
            </span>
          </div>
          <div style="display:flex;flex-direction:column;gap:10px">
            ${analysis.nlpSignals.length
              ? analysis.nlpSignals.map(s => Utils.confidenceBar(s.score, s.signal)).join('')
              : '<div style="color:var(--text-muted);font-size:13px">No manipulation signals detected</div>'
            }
          </div>
          <div style="margin-top:14px">
            <div style="font-size:11px;font-weight:700;color:var(--text-muted);margin-bottom:6px">Sender Analysis</div>
            <div class="ioc-entry">
              <span class="ioc-type domain">FROM</span>
              <span class="ioc-value">${analysis.fromAddr}</span>
            </div>
            <div class="ioc-entry">
              <span class="ioc-type ip">IP</span>
              <span class="ioc-value">${analysis.originIP}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- IOCs -->
      <div class="section-title">Indicators of Compromise (IOCs)</div>
      <div style="margin-bottom:20px">
        ${analysis.iocs.map(ioc => `
          <div class="ioc-entry">
            <span class="ioc-type ${ioc.type}">${ioc.type.toUpperCase()}</span>
            <span class="ioc-value">${ioc.value}</span>
            ${ioc.vt_score ? `<span style="font-size:11px;color:${ioc.verdict === 'CLEAN' ? 'var(--accent-green)' : ioc.verdict === 'MALICIOUS' ? 'var(--accent-red)' : 'var(--accent-amber)'}">VT: ${ioc.vt_score}</span>` : ''}
            <span style="font-size:11px;font-weight:700;color:${ioc.verdict === 'CLEAN' ? 'var(--accent-green)' : ioc.verdict === 'MALICIOUS' ? 'var(--accent-red)' : 'var(--accent-amber)'}">${ioc.verdict}</span>
            <button class="ioc-copy" onclick="navigator.clipboard.writeText('${ioc.value}').then(()=>Utils.notify('Copied!','success'))">Copy</button>
          </div>
        `).join('')}
      </div>

      <!-- URLs Found -->
      ${analysis.urls.length ? `
        <div class="section-title">URLs Extracted</div>
        <div class="terminal" style="margin-bottom:20px">
          <div class="terminal-header">
            <div class="terminal-dots"><div class="terminal-dot red"></div><div class="terminal-dot amber"></div><div class="terminal-dot green"></div></div>
            <span class="terminal-title">URL Scanner — VirusTotal API</span>
          </div>
          <div class="terminal-body">
            ${analysis.urls.map(url => `
              <div class="log-line">
                <span class="log-level ${analysis.verdict === 'SAFE' ? 'SUCCESS' : 'ERROR'}">${analysis.verdict === 'SAFE' ? 'CLEAN' : 'THREAT'}</span>
                <span class="log-msg mono" style="word-break:break-all">${url}</span>
              </div>
            `).join('')}
          </div>
        </div>
      ` : ''}
    `;

    document.getElementById('ph-result-state').innerHTML = html;
    Utils.animateProgressBars();
    Utils.notify(`Analysis complete — verdict: ${analysis.verdict} (${analysis.confidence}% confidence)`,
      analysis.verdict === 'SAFE' ? 'success' : analysis.verdict === 'PHISHING' ? 'error' : 'warning', 5000);
  }

  function showYARA() {
    if (!currentAnalysis) return;
    const modal   = document.getElementById('ph-yara-modal');
    const content = document.getElementById('ph-yara-content');
    if (!modal || !content) return;

    const analysis = currentAnalysis;
    const domains  = analysis.iocs.filter(i => i.type === 'domain').map(i => i.value);
    const ips      = analysis.iocs.filter(i => i.type === 'ip').map(i => i.value);

    const yaraRule = ReportEngine.generateYARA(
      { description: `Phishing email impersonating ${analysis.senderDomain}`, threatLevel: analysis.verdict, reference: analysis.fromAddr },
      [
        ...domains.map(d => ({ type: 'string', value: d, modifier: 'nocase ascii wide' })),
        { type: 'string', value: analysis.subject.slice(0, 40), modifier: 'nocase ascii' },
        ...(analysis.verdict !== 'SAFE' ? [{ type: 'string', value: 'URGENT', modifier: 'nocase' }, { type: 'string', value: 'suspended', modifier: 'nocase' }] : []),
      ],
      `any of them and ${analysis.verdict !== 'SAFE' ? '(#s0 > 0 or #s1 > 0)' : 'all of them'}`
    );

    const suricataRule = ReportEngine.generateSuricata(
      { proto: 'http', msg: `Phishing - ${analysis.senderDomain} impersonation`, classtype: 'social-engineering', confidence: analysis.verdict },
      ips.length ? ips.join(',') : 'any',
      'any',
      domains.slice(0, 2)
    );

    content.innerHTML = `
      <div class="tabs" style="margin-bottom:16px" id="yara-tabs">
        <button class="tab-btn active" onclick="PhishingAgent.switchYaraTab('yara',this)">YARA Rule</button>
        <button class="tab-btn" onclick="PhishingAgent.switchYaraTab('suricata',this)">Suricata Rule</button>
        <button class="tab-btn" onclick="PhishingAgent.switchYaraTab('soar',this)">SOAR JSON</button>
      </div>

      <div id="yara-panel-yara">
        <div class="code-output-header">
          <span>YARA Rule</span>
          <button class="btn btn-ghost btn-sm" onclick="Utils.downloadText(document.getElementById('yara-code').textContent,'phishing.yar')">⬇ Download</button>
        </div>
        <div class="code-output" id="yara-code">${yaraRule}</div>
      </div>

      <div id="yara-panel-suricata" style="display:none">
        <div class="code-output-header">
          <span>Suricata IDS Rule</span>
          <button class="btn btn-ghost btn-sm" onclick="Utils.downloadText(document.getElementById('suricata-code').textContent,'phishing.rules')">⬇ Download</button>
        </div>
        <div class="code-output" id="suricata-code">${suricataRule}</div>
      </div>

      <div id="yara-panel-soar" style="display:none">
        <div class="code-output-header">
          <span>SOAR Playbook JSON</span>
          <button class="btn btn-ghost btn-sm" onclick="PhishingAgent.exportJSON()">⬇ Download</button>
        </div>
        <div class="code-output" style="font-size:11px">${JSON.stringify({
          playbook: 'phishing_response',
          verdict: analysis.verdict,
          confidence: analysis.confidence,
          iocs: analysis.iocs,
          actions: analysis.verdict === 'PHISHING'
            ? ['quarantine_email', 'block_sender_domain', 'block_ips', 'alert_security_team', 'reset_user_creds']
            : ['flag_for_review', 'notify_user'],
          mitre: 'T1566 — Phishing',
        }, null, 2)}</div>
      </div>
    `;

    modal.classList.remove('hidden');
  }

  function switchYaraTab(tab, btn) {
    document.querySelectorAll('#yara-tabs .tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    ['yara','suricata','soar'].forEach(t => {
      const p = document.getElementById(`yara-panel-${t}`);
      if (p) p.style.display = t === tab ? 'block' : 'none';
    });
  }

  function exportJSON() {
    if (!currentAnalysis) { Utils.notify('Analyze an email first', 'warning'); return; }
    const report = ReportEngine.buildJSONReport('Phishing Email Analyzer', currentAnalysis.fromAddr, [{
      id: 'PH001', severity: currentAnalysis.verdict === 'PHISHING' ? 'CRITICAL' : currentAnalysis.verdict === 'SUSPICIOUS' ? 'HIGH' : 'INFO',
      title: currentAnalysis.verdict,
      verdict: currentAnalysis.verdict,
      confidence: currentAnalysis.confidence,
      iocs: currentAnalysis.iocs,
      spf: currentAnalysis.spfResult,
      dkim: currentAnalysis.dkimResult,
      dmarc: currentAnalysis.dmarcResult,
    }]);
    Utils.downloadJSON(report, `phishing-analysis-${Date.now()}.json`);
    Utils.notify('SOAR JSON downloaded', 'success');
  }

  function reset() {
    document.getElementById('ph-result-state').style.display = 'none';
    document.getElementById('ph-result-state').innerHTML = '';
    const ta = document.getElementById('ph-email-input');
    if (ta) ta.value = '';
    currentAnalysis = null;
  }

  function init() {
    setTimeout(() => {
      const fi = document.getElementById('ph-eml-input');
      if (fi) fi.addEventListener('change', e => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = ev => {
          const ta = document.getElementById('ph-email-input');
          if (ta) ta.value = ev.target.result;
          analyzeEmail();
        };
        reader.readAsText(file);
      });
    }, 100);
  }

  return { render, init, loadSample, analyzeEmail, showYARA, switchYaraTab, exportJSON, reset };
})();
