/* ============================================================
   AI PROTECT — AGENT 1: Mobile App Vulnerability Scanner
   ============================================================ */

window.MobileVulnAgent = (() => {

  const VULN_DB = {
    android: [
      {
        id: 'MA001', severity: 'CRITICAL', title: 'Hardcoded API Key in Source Code',
        component: 'com.app.api.ApiClient',
        file: 'src/main/java/com/app/api/ApiClient.java', line: 42,
        snippet: 'private static final String API_KEY = "AIzaSyD-XXXXXXXXXXXXXXXXXXXXXXXX";',
        description: 'A live production API key is hardcoded directly in the source code. Attackers who decompile the APK can extract and abuse this key.',
        recommendation: 'Store secrets in encrypted keystores or use a secure backend proxy. Never embed secrets in client-side code.',
        mitreId: 'T1552', cweId: 798
      },
      {
        id: 'MA002', severity: 'CRITICAL', title: 'Plaintext SQLite Database (No Encryption)',
        component: 'com.app.data.DatabaseHelper',
        file: 'src/main/java/com/app/data/DatabaseHelper.java', line: 28,
        snippet: 'SQLiteDatabase db = openOrCreateDatabase("user_data.db", MODE_PRIVATE, null);',
        description: 'The SQLite database is created without encryption. On rooted devices, any app with root access can read the full database including PII and session tokens.',
        recommendation: 'Use SQLCipher to encrypt the database. Apply AES-256 encryption with a key derived from user credentials.',
        mitreId: 'T1005', cweId: 312
      },
      {
        id: 'MA003', severity: 'HIGH', title: 'Sensitive Data in SharedPreferences (Plaintext)',
        component: 'com.app.auth.SessionManager',
        file: 'src/main/java/com/app/auth/SessionManager.java', line: 67,
        snippet: 'prefs.edit().putString("auth_token", token).apply();\nprefs.edit().putString("user_password", password).apply();',
        description: 'Authentication tokens and passwords are stored in SharedPreferences without encryption. These XML files are readable on rooted or backed-up devices.',
        recommendation: 'Use Android Keystore System with EncryptedSharedPreferences from Jetpack Security library.',
        mitreId: 'T1539', cweId: 312
      },
      {
        id: 'MA004', severity: 'HIGH', title: 'SSL/TLS Certificate Validation Disabled',
        component: 'com.app.network.TrustManager',
        file: 'src/main/java/com/app/network/HttpClient.java', line: 103,
        snippet: 'hostnameVerifier = (hostname, session) -> true; // TODO: fix for prod\ntm.checkServerTrusted(chain, authType); // noop',
        description: 'The app accepts all SSL certificates including self-signed and expired ones. This leaves all network traffic exposed to MITM attacks.',
        recommendation: 'Implement proper certificate validation and enable certificate pinning using OkHttp CertificatePinner or Android Network Security Config.',
        mitreId: 'T1557', cweId: 295
      },
      {
        id: 'MA005', severity: 'HIGH', title: 'Weak Cryptographic Algorithm (MD5/SHA1)',
        component: 'com.app.utils.CryptoUtils',
        file: 'src/main/java/com/app/utils/CryptoUtils.java', line: 19,
        snippet: 'MessageDigest md = MessageDigest.getInstance("MD5");\nbyte[] hash = md.digest(password.getBytes());',
        description: 'MD5 is cryptographically broken. Password hashes using MD5 can be cracked using rainbow tables in seconds.',
        recommendation: 'Replace MD5/SHA1 with bcrypt, Argon2, or PBKDF2 for password hashing. Use SHA-256+ for integrity checks.',
        mitreId: 'T1040', cweId: 327
      },
      {
        id: 'MA006', severity: 'MEDIUM', title: 'Exported Activity Without Permission Check',
        component: 'com.app.ui.AdminActivity',
        file: 'src/main/AndroidManifest.xml', line: 88,
        snippet: '<activity android:name=".AdminActivity" android:exported="true">\n    <!-- No android:permission attribute -->\n</activity>',
        description: 'AdminActivity is exported with no permission restriction. Any app on the device can launch it directly via an intent, bypassing authentication.',
        recommendation: 'Add android:permission="com.app.ADMIN_ACCESS" and verify caller identity inside the activity.',
        mitreId: 'T1548', cweId: 926
      },
      {
        id: 'MA007', severity: 'MEDIUM', title: 'Insecure WebView JavaScript Bridge',
        component: 'com.app.web.WebViewActivity',
        file: 'src/main/java/com/app/web/WebViewActivity.java', line: 55,
        snippet: 'webView.getSettings().setJavaScriptEnabled(true);\nwebView.addJavascriptInterface(new NativeBridge(this), "Android");',
        description: 'JavaScript interface is exposed to WebView content. If the app loads external or attacker-controlled URLs, JavaScript can call native Android methods.',
        recommendation: 'Validate all URLs loaded in WebView. Use a whitelist approach. Disable addJavascriptInterface if not strictly needed.',
        mitreId: 'T1059', cweId: 749
      },
      {
        id: 'MA008', severity: 'MEDIUM', title: 'Log Leakage: PII in Logcat',
        component: 'com.app.auth.LoginActivity',
        file: 'src/main/java/com/app/auth/LoginActivity.java', line: 144,
        snippet: 'Log.d("LoginActivity", "User login: " + username + " / " + password);\nLog.v("API", "Response token: " + response.getToken());',
        description: 'Debug logs print sensitive data (passwords, tokens) to Logcat. On Android < 4.1, all apps can read Logcat. Debug builds on test devices expose production credentials.',
        recommendation: 'Remove all Log statements containing sensitive data. Use ProGuard to strip logs in release builds. Use a logging framework with severity gates.',
        mitreId: 'T1005', cweId: 532
      },
      {
        id: 'MA009', severity: 'LOW', title: 'Backup Enabled for Sensitive Data',
        component: 'AndroidManifest.xml',
        file: 'src/main/AndroidManifest.xml', line: 5,
        snippet: '<application android:allowBackup="true"\n    android:fullBackupContent="true">',
        description: 'Cloud backup is enabled. Sensitive data in the app\'s private directory can be backed up to Google Drive and restored on attacker devices via ADB backup.',
        recommendation: 'Set android:allowBackup="false" or define a backup rules file that excludes sensitive data.',
        mitreId: 'T1005', cweId: 530
      },
      {
        id: 'MA010', severity: 'LOW', title: 'Debuggable Flag Enabled in Release',
        component: 'AndroidManifest.xml',
        file: 'src/main/AndroidManifest.xml', line: 6,
        snippet: '<application android:debuggable="true" ...>',
        description: 'The app is marked debuggable. Attackers can attach debuggers, inspect memory, and extract runtime secrets from the process.',
        recommendation: 'Ensure android:debuggable="false" in release builds. This should be automatically handled by release build type in Gradle.',
        mitreId: 'T1082', cweId: 215
      },
    ],

    ios: [
      {
        id: 'MI001', severity: 'CRITICAL', title: 'Keychain Items with kSecAttrAccessibleAlways',
        component: 'AuthManager.swift',
        file: 'Sources/Auth/AuthManager.swift', line: 34,
        snippet: 'let query: [String: Any] = [\n  kSecClass as String: kSecClassGenericPassword,\n  kSecAttrAccessible as String: kSecAttrAccessibleAlways,\n  kSecValueData as String: tokenData\n]',
        description: 'Keychain items stored with kSecAttrAccessibleAlways are accessible even when the device is locked. This allows extraction without authentication.',
        recommendation: 'Use kSecAttrAccessibleWhenUnlockedThisDeviceOnly or kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly.',
        mitreId: 'T1555', cweId: 312
      },
      {
        id: 'MI002', severity: 'CRITICAL', title: 'Hardcoded AWS Credentials',
        component: 'S3UploadService.swift',
        file: 'Sources/Services/S3UploadService.swift', line: 12,
        snippet: 'let accessKey = "AKIAIOSFODNN7EXAMPLE"\nlet secretKey = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"',
        description: 'AWS access key and secret key are hardcoded. Anyone who runs strings on the IPA binary can extract and use these to access the AWS account.',
        recommendation: 'Use IAM roles, STS AssumeRole, or Cognito Identity Pools. Fetch credentials dynamically from a secure backend at runtime.',
        mitreId: 'T1552', cweId: 798
      },
      {
        id: 'MI003', severity: 'HIGH', title: 'Certificate Pinning Bypassed via Allow List',
        component: 'NetworkSession.swift',
        file: 'Sources/Network/NetworkSession.swift', line: 78,
        snippet: 'func urlSession(_ session: URLSession,\n  didReceive challenge: URLAuthenticationChallenge) {\n  completionHandler(.useCredential, URLCredential(trust: challenge.protectionSpace.serverTrust!))\n}',
        description: 'The app blindly trusts the server\'s certificate without any pinning validation, making it vulnerable to MITM attacks.',
        recommendation: 'Implement TrustKit or manual certificate pinning using SecPolicyCreateSSL and certificate comparison.',
        mitreId: 'T1557', cweId: 295
      },
      {
        id: 'MI004', severity: 'HIGH', title: 'Sensitive Data Stored in NSUserDefaults',
        component: 'UserSession.swift',
        file: 'Sources/Auth/UserSession.swift', line: 22,
        snippet: 'UserDefaults.standard.set(authToken, forKey: "auth_token")\nUserDefaults.standard.set(creditCardNumber, forKey: "cc_number")',
        description: 'NSUserDefaults stores data as plaintext plist. Sensitive values like auth tokens and payment info are accessible on jailbroken devices.',
        recommendation: 'Move all sensitive data to the Keychain with appropriate accessibility flags.',
        mitreId: 'T1539', cweId: 312
      },
      {
        id: 'MI005', severity: 'MEDIUM', title: 'App Transport Security Disabled',
        component: 'Info.plist',
        file: 'Resources/Info.plist', line: 45,
        snippet: '<key>NSAppTransportSecurity</key>\n<dict>\n  <key>NSAllowsArbitraryLoads</key>\n  <true/>\n</dict>',
        description: 'ATS is fully disabled. The app can make HTTP connections to any server, exposing data to interception.',
        recommendation: 'Enable ATS. If specific domains need exceptions, list them explicitly with NSExceptionDomains.',
        mitreId: 'T1557', cweId: 319
      },
    ]
  };

  let currentFindings = [];
  let scanInterval = null;

  // ── Render Agent UI ─────────────────────────────────────────
  function render() {
    return `
    <div class="agent-hero">
      <div class="agent-hero-left">
        <div class="agent-hero-icon" style="background:linear-gradient(135deg,#7c3aed,#4f46e5)">📱</div>
        <div>
          <div class="agent-hero-title">Mobile App Vulnerability Scanner</div>
          <div class="agent-hero-sub">Decompile APK/IPA · Detect insecure storage · Verify HTTPS · Audit encryption</div>
        </div>
      </div>
      <div class="agent-hero-right">
        <span class="pill">🤖 Agent v2.4</span>
        <span class="pill">OWASP Mobile Top 10</span>
      </div>
    </div>

    <div id="mv-upload-state">
      <div class="grid-2" style="gap:16px;margin-bottom:16px">
        <div class="upload-zone" id="mv-apk-zone" onclick="document.getElementById('mv-file-input').click()">
          <span class="upload-icon">🤖</span>
          <div class="upload-title">Drop APK File</div>
          <div class="upload-sub">Android Package — decompile & scan</div>
          <div class="upload-hint">APK · AAB · DEX</div>
        </div>
        <div class="upload-zone" id="mv-ipa-zone" onclick="document.getElementById('mv-file-input').click()">
          <span class="upload-icon">🍎</span>
          <div class="upload-title">Drop IPA File</div>
          <div class="upload-sub">iOS App Archive — static analysis</div>
          <div class="upload-hint">IPA · XCARCHIVE</div>
        </div>
      </div>
      <input type="file" id="mv-file-input" accept=".apk,.ipa,.aab" style="display:none">
      <div style="text-align:center;margin-bottom:16px">
        <span style="font-size:12px;color:var(--text-muted)">— or demo with sample —</span>
      </div>
      <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap">
        <button class="btn btn-primary" onclick="MobileVulnAgent.runDemo('android')">
          🤖 Scan Sample APK
        </button>
        <button class="btn btn-outline" onclick="MobileVulnAgent.runDemo('ios')">
          🍎 Scan Sample IPA
        </button>
      </div>
    </div>

    <div id="mv-scan-state" style="display:none">
      <div class="scan-container">
        <div class="scan-ring-wrap">
          <div class="scan-ring scan-ring-1"></div>
          <div class="scan-ring scan-ring-2"></div>
          <div class="scan-ring scan-ring-3"></div>
          <div class="scan-pulse"></div>
          <div class="scan-inner">📱</div>
        </div>
        <div class="scan-status" id="mv-scan-status">Initializing scanner...</div>
        <div class="scan-detail" id="mv-scan-detail"></div>
        <div class="scan-progress-bar">
          <div class="scan-progress-fill" id="mv-progress-fill"></div>
        </div>
        <div class="scan-steps" id="mv-scan-steps"></div>
      </div>
    </div>

    <div id="mv-result-state" style="display:none"></div>
    `;
  }

  // ── Run Demo Scan ───────────────────────────────────────────
  async function runDemo(platform) {
    document.getElementById('mv-upload-state').style.display = 'none';
    document.getElementById('mv-scan-state').style.display   = 'block';
    document.getElementById('mv-result-state').style.display = 'none';

    const steps = [
      { label: 'Unpacking archive', detail: 'Extracting APK/IPA contents…' },
      { label: 'Parsing manifest', detail: `Analyzing ${platform === 'android' ? 'AndroidManifest.xml' : 'Info.plist'}…` },
      { label: 'Decompiling bytecode', detail: platform === 'android' ? 'Running jadx decompiler…' : 'Parsing ARM64 binary…' },
      { label: 'Static code analysis', detail: 'Scanning for hardcoded secrets, weak crypto…' },
      { label: 'Network security audit', detail: 'Verifying TLS config, certificate pinning…' },
      { label: 'Data storage audit', detail: `Checking ${platform === 'android' ? 'SharedPreferences, SQLite' : 'NSUserDefaults, Keychain'}…` },
      { label: 'Generating report', detail: 'Ranking findings by severity…' },
    ];

    const stepsEl   = document.getElementById('mv-scan-steps');
    const statusEl  = document.getElementById('mv-scan-status');
    const detailEl  = document.getElementById('mv-scan-detail');
    const progressEl= document.getElementById('mv-progress-fill');

    stepsEl.innerHTML = steps.map((s, i) =>
      `<div class="scan-step" id="mv-step-${i}">
        <div class="scan-step-icon">○</div>
        <span>${s.label}</span>
      </div>`
    ).join('');

    for (let i = 0; i < steps.length; i++) {
      const stepEl = document.getElementById(`mv-step-${i}`);
      if (!stepEl) break;

      // Mark previous done
      if (i > 0) {
        const prev = document.getElementById(`mv-step-${i-1}`);
        if (prev) { prev.className = 'scan-step done'; prev.querySelector('.scan-step-icon').textContent = '✓'; }
      }

      stepEl.className = 'scan-step active';
      stepEl.querySelector('.scan-step-icon').textContent = '◉';
      statusEl.textContent  = steps[i].label + '…';
      detailEl.textContent  = steps[i].detail;
      progressEl.style.width = `${Math.round((i + 1) / steps.length * 100)}%`;

      await Utils.sleep(Utils.randomBetween(500, 900));
    }

    // Mark last done
    const last = document.getElementById(`mv-step-${steps.length-1}`);
    if (last) { last.className = 'scan-step done'; last.querySelector('.scan-step-icon').textContent = '✓'; }

    statusEl.textContent = 'Scan complete!';
    progressEl.style.width = '100%';

    await Utils.sleep(600);
    showResults(platform);
  }

  // ── Show Results ────────────────────────────────────────────
  function showResults(platform) {
    document.getElementById('mv-scan-state').style.display   = 'none';
    document.getElementById('mv-result-state').style.display = 'block';

    const findings = VULN_DB[platform];
    currentFindings = findings;
    const target = platform === 'android' ? 'com.example.mobileapp v3.2.1 (APK)' : 'ExampleApp v2.0.1 (IPA)';

    const counts = {
      CRITICAL: findings.filter(f => f.severity === 'CRITICAL').length,
      HIGH:     findings.filter(f => f.severity === 'HIGH').length,
      MEDIUM:   findings.filter(f => f.severity === 'MEDIUM').length,
      LOW:      findings.filter(f => f.severity === 'LOW').length,
    };

    const riskScore = counts.CRITICAL * 25 + counts.HIGH * 15 + counts.MEDIUM * 8 + counts.LOW * 2;
    const riskLabel = riskScore > 70 ? 'CRITICAL RISK' : riskScore > 40 ? 'HIGH RISK' : 'MEDIUM RISK';

    const html = `
      ${ReportEngine.reportHeader({
        agentName: 'Mobile App Vulnerability Scanner',
        target,
        scanTime: Utils.now(),
        riskScore: Math.min(riskScore, 99),
        riskLabel
      })}

      <div style="display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap">
        <button class="btn btn-primary" onclick="MobileVulnAgent.downloadReport('json')">⬇ Export JSON</button>
        <button class="btn btn-ghost" onclick="MobileVulnAgent.downloadReport('csv')">⬇ Export CSV</button>
        <button class="btn btn-ghost" onclick="MobileVulnAgent.reset()">↩ New Scan</button>
      </div>

      <div class="spacer">${ReportEngine.summaryTable(counts, 'Vulnerability Summary')}</div>

      <div class="section-title">Detailed Findings</div>
      <div style="display:flex;flex-direction:column;gap:12px">
        ${ReportEngine.findingsList(findings)}
      </div>
    `;

    document.getElementById('mv-result-state').innerHTML = html;
    Utils.animateProgressBars();
    Utils.notify(`Scan complete — ${counts.CRITICAL} critical, ${counts.HIGH} high severity issues found`, 'warning');
  }

  function downloadReport(type) {
    const report = ReportEngine.buildJSONReport('Mobile App Vulnerability Scanner', 'Mobile App', currentFindings);
    if (type === 'json') Utils.downloadJSON(report, 'mobile-vuln-report.json');
    else ReportEngine.buildCSV(currentFindings, ['id','severity','title','component','file','line','description','recommendation','cweId','mitreId']);
  }

  function reset() {
    document.getElementById('mv-upload-state').style.display = '';
    document.getElementById('mv-scan-state').style.display   = 'none';
    document.getElementById('mv-result-state').style.display = 'none';
    currentFindings = [];
  }

  function init() {
    // Drag and drop
    setTimeout(() => {
      ['mv-apk-zone','mv-ipa-zone'].forEach(id => {
        const el = document.getElementById(id);
        if (!el) return;
        el.addEventListener('dragover', e => { e.preventDefault(); el.classList.add('drag-over'); });
        el.addEventListener('dragleave', () => el.classList.remove('drag-over'));
        el.addEventListener('drop', e => {
          e.preventDefault();
          el.classList.remove('drag-over');
          const file = e.dataTransfer.files[0];
          if (file) {
            const platform = file.name.endsWith('.ipa') ? 'ios' : 'android';
            runDemo(platform);
          }
        });
      });
      const fi = document.getElementById('mv-file-input');
      if (fi) fi.addEventListener('change', e => {
        const file = e.target.files[0];
        if (file) {
          const platform = file.name.endsWith('.ipa') ? 'ios' : 'android';
          runDemo(platform);
        }
      });
    }, 100);
  }

  return { render, runDemo, init, downloadReport, reset };
})();
