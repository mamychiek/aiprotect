/* ============================================================
   AI PROTECT — AGENT 5: Insider Threat Detection (UEBA)
   ============================================================ */

window.UEBAAgent = (() => {

  const DEPARTMENTS = ['Engineering', 'Finance', 'HR', 'Legal', 'DevOps', 'Marketing', 'Executive', 'IT Security'];
  const FIRST_NAMES = ['Alice', 'Bob', 'Carol', 'David', 'Eve', 'Frank', 'Grace', 'Henry', 'Iris', 'James'];
  const LAST_NAMES  = ['Chen', 'Martinez', 'Johnson', 'Williams', 'Brown', 'Taylor', 'Anderson', 'Wilson'];

  const ANOMALY_TYPES = [
    {
      id: 'after_hours_download',
      title: 'After-Hours Bulk File Download',
      mitreId: 'T1074',
      severity: 'CRITICAL',
      icon: '💾',
      detail: (u) => `${u.name} downloaded ${Utils.randomBetween(120, 800)} MB from ${u.dept} shared drive at 02:${Utils.randomBetween(10,59).toString().padStart(2,'0')} AM. Baseline: 0 MB after midnight.`,
      remediation: 'Immediately revoke network access and preserve evidence. Escalate to incident response.',
    },
    {
      id: 'impossible_travel',
      title: 'Impossible Travel Detected',
      mitreId: 'T1078',
      severity: 'CRITICAL',
      icon: '✈️',
      detail: (u) => `Login from New York, US at 09:14 AM, then ${Utils.randomChoice(['London, UK', 'Dubai, UAE', 'Tokyo, JP', 'Sydney, AU'])} at 09:47 AM — 33 min gap, 5,000+ km distance.`,
      remediation: 'Terminate all active sessions. Force password reset. Investigate credential compromise.',
    },
    {
      id: 'unauthorized_admin',
      title: 'Unauthorized Admin Account Created',
      mitreId: 'T1136',
      severity: 'CRITICAL',
      icon: '👑',
      detail: (u) => `Non-IT user ${u.name} (${u.dept}) created local admin account 'backup_admin' on server PROD-SRV-04 at 11:32 PM.`,
      remediation: 'Immediately disable created account. Remove admin privileges. Alert security manager.',
    },
    {
      id: 'large_email_attachment',
      title: 'Unusual Email Attachment Volume',
      mitreId: 'T1048',
      severity: 'HIGH',
      icon: '📧',
      detail: (u) => `${u.name} sent ${Utils.randomBetween(15, 45)} emails with attachments totaling ${Utils.randomBetween(200, 600)} MB to personal Gmail. Normal: 2 emails/day.`,
      remediation: 'Review email content for IP. Notify legal for potential data exfiltration.',
    },
    {
      id: 'vpn_off_hours',
      title: 'VPN Access — Unusual Hours & Location',
      mitreId: 'T1133',
      severity: 'HIGH',
      icon: '🔐',
      detail: (u) => `VPN connection from ${Utils.randomChoice(['Moscow, RU', 'Minsk, BY', 'Bucharest, RO'])} at 03:22 AM. User ${u.name} was on approved leave this week.`,
      remediation: 'Block VPN session. Verify with employee. Check for credential theft.',
    },
    {
      id: 'sensitive_folder_access',
      title: 'Access to Restricted Data Repository',
      mitreId: 'T1005',
      severity: 'MEDIUM',
      icon: '📁',
      detail: (u) => `${u.name} accessed /finance/acquisitions/CONFIDENTIAL/ — ${Utils.randomBetween(40, 120)} files viewed in 8 minutes. Role: ${u.dept} (no access required).`,
      remediation: 'Review access logs. Revoke unauthorized access. Notify data owner.',
    },
  ];

  let users = [];
  let monitoring = false;
  let digestInterval = null;
  let digestSent = false;

  function generateUsers() {
    return FIRST_NAMES.slice(0, 8).map((fn, i) => {
      const ln    = LAST_NAMES[i % LAST_NAMES.length];
      const dept  = DEPARTMENTS[i % DEPARTMENTS.length];
      const name  = `${fn} ${ln}`;

      // Assign anomalies to some users
      const hasAnomaly  = i < 5;
      const anomaly     = hasAnomaly ? ANOMALY_TYPES[i % ANOMALY_TYPES.length] : null;
      const riskScore   = hasAnomaly
        ? anomaly.severity === 'CRITICAL' ? Utils.randomBetween(82, 99) : Utils.randomBetween(55, 79)
        : Utils.randomBetween(5, 30);

      const loginHours  = hasAnomaly
        ? ['02:14 AM', '11:47 PM', '03:22 AM'][i % 3] || '09:15 AM'
        : `${Utils.randomBetween(8, 10).toString().padStart(2,'0')}:${Utils.randomBetween(0,59).toString().padStart(2,'0')} AM`;

      const dataTransfer = hasAnomaly ? Utils.randomBetween(150, 800) + ' MB' : Utils.randomBetween(2, 45) + ' MB';
      const anomalyCount = hasAnomaly ? Utils.randomBetween(2, 5) : 0;

      return {
        id: `USR${String(i+1).padStart(3,'0')}`,
        name, dept, riskScore, hasAnomaly, anomaly, loginHours, dataTransfer, anomalyCount,
        avatar: fn[0] + ln[0],
        bgColor: hasAnomaly
          ? ['rgba(255,51,102,0.2)', 'rgba(255,107,53,0.2)', 'rgba(255,184,0,0.2)'][Math.min(i,2)]
          : 'rgba(0,255,136,0.1)',
        riskColor: riskScore > 80 ? 'var(--accent-red)' : riskScore > 50 ? 'var(--accent-amber)' : 'var(--accent-green)',
      };
    });
  }

  // ── Render ─────────────────────────────────────────────────
  function render() {
    users = generateUsers();
    const topUsers = [...users].sort((a, b) => b.riskScore - a.riskScore).slice(0, 5);

    return `
    <div class="agent-hero">
      <div class="agent-hero-left">
        <div class="agent-hero-icon" style="background:linear-gradient(135deg,#00ffd5,#0066ff)">👤</div>
        <div>
          <div class="agent-hero-title">Insider Threat Detection (UEBA)</div>
          <div class="agent-hero-sub">30-day behavioral baseline · Anomaly scoring · Impossible travel · Data exfiltration detection</div>
        </div>
      </div>
      <div class="agent-hero-right">
        <span class="pill">AD Logs</span>
        <span class="pill">VPN Events</span>
        <span class="pill">File Access</span>
        <button class="btn btn-primary btn-sm" onclick="UEBAAgent.runAnalysis()">🔍 Run Analysis</button>
      </div>
    </div>

    <!-- Stats -->
    <div class="dashboard-grid" style="margin-bottom:20px">
      <div class="stat-card" style="--card-accent:#ff3366">
        <span class="stat-card-icon">🚨</span>
        <div class="stat-card-value">${users.filter(u => u.hasAnomaly && u.anomaly?.severity === 'CRITICAL').length}</div>
        <div class="stat-card-label">Critical Anomalies</div>
      </div>
      <div class="stat-card" style="--card-accent:#ffb800">
        <span class="stat-card-icon">⚡</span>
        <div class="stat-card-value">${users.filter(u => u.hasAnomaly).length}</div>
        <div class="stat-card-label">Users Flagged</div>
      </div>
      <div class="stat-card" style="--card-accent:#00ffd5">
        <span class="stat-card-icon">👥</span>
        <div class="stat-card-value">${users.length}</div>
        <div class="stat-card-label">Users Monitored</div>
      </div>
      <div class="stat-card" style="--card-accent:#7c3aed">
        <span class="stat-card-icon">📅</span>
        <div class="stat-card-value">30</div>
        <div class="stat-card-label">Day Baseline</div>
      </div>
    </div>

    <div class="grid-2" style="gap:16px">
      <!-- Top Risk Users -->
      <div>
        <div class="section-title">Top 5 Riskiest Users — Daily Digest
          <button class="btn btn-ghost btn-sm" style="margin-left:auto" onclick="UEBAAgent.sendSlackDigest()">
            💬 Send to Slack
          </button>
        </div>
        <div id="ueba-user-list">
          ${topUsers.map((u, rank) => renderUserCard(u, rank + 1)).join('')}
        </div>
      </div>

      <!-- Activity Heatmap -->
      <div>
        <div class="section-title">Login Activity Heatmap (24h × 7d)</div>
        <div class="card" style="padding:16px">
          <div id="ueba-heatmap">${renderHeatmap()}</div>
          <div style="display:flex;align-items:center;gap:8px;margin-top:10px;font-size:11px;color:var(--text-muted)">
            <span>Low</span>
            ${['rgba(0,255,136,0.1)','rgba(0,255,136,0.3)','rgba(255,184,0,0.4)','rgba(255,107,53,0.6)','rgba(255,51,102,0.8)']
              .map(c => `<div style="width:16px;height:16px;background:${c};border-radius:3px"></div>`).join('')}
            <span>High Risk</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Anomaly Events Feed -->
    <div style="margin-top:20px">
      <div class="section-title">Detected Anomaly Events</div>
      <div id="ueba-anomaly-feed" style="display:flex;flex-direction:column;gap:10px">
        ${users.filter(u => u.hasAnomaly).map(u => renderAnomalyCard(u)).join('')}
      </div>
    </div>

    <!-- User Detail Modal -->
    <div class="modal-overlay hidden" id="ueba-user-modal">
      <div class="modal-box" style="max-width:640px">
        <div class="modal-header">
          <div class="modal-title">👤 User Behavior Profile</div>
          <button class="modal-close" onclick="document.getElementById('ueba-user-modal').classList.add('hidden')">✕</button>
        </div>
        <div id="ueba-user-modal-content"></div>
      </div>
    </div>

    <!-- Slack Modal -->
    <div class="modal-overlay hidden" id="ueba-slack-modal">
      <div class="modal-box" style="max-width:600px">
        <div class="modal-header">
          <div class="modal-title">💬 Slack Daily Digest</div>
          <button class="modal-close" onclick="document.getElementById('ueba-slack-modal').classList.add('hidden')">✕</button>
        </div>
        <div id="ueba-slack-content"></div>
      </div>
    </div>
    `;
  }

  function renderUserCard(user, rank) {
    return `<div class="user-risk-card" onclick="UEBAAgent.showUserDetail('${user.id}')">
      <div style="width:24px;height:24px;border-radius:50%;background:${user.riskColor}22;
        display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:${user.riskColor}">
        ${rank}
      </div>
      <div class="user-avatar" style="background:${user.bgColor};color:${user.riskColor}">
        ${user.avatar}
      </div>
      <div class="user-info">
        <div class="user-name">${user.name}</div>
        <div class="user-dept">${user.dept} ${user.hasAnomaly ? `· ${user.anomalyCount} anomalies` : '· Normal'}</div>
      </div>
      <div style="flex:1;padding:0 10px">
        ${Utils.confidenceBar(user.riskScore)}
      </div>
      <div class="risk-score-circle" style="color:${user.riskColor};border-color:${user.riskColor}40">
        ${user.riskScore}
      </div>
    </div>`;
  }

  function renderHeatmap() {
    const days  = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const hours = Array.from({length: 24}, (_, i) => i);

    const colorFor = (val) => {
      if (val < 0.1) return 'rgba(0,255,136,0.05)';
      if (val < 0.3) return 'rgba(0,255,136,0.2)';
      if (val < 0.5) return 'rgba(255,184,0,0.3)';
      if (val < 0.75) return 'rgba(255,107,53,0.5)';
      return 'rgba(255,51,102,0.8)';
    };

    return `
      <div style="overflow-x:auto">
        <div style="display:grid;grid-template-columns:32px repeat(24,1fr);gap:2px;min-width:500px">
          <div></div>
          ${hours.map(h => `<div style="font-size:8px;color:var(--text-muted);text-align:center">${h}</div>`).join('')}
          ${days.map(day => `
            <div style="font-size:10px;color:var(--text-muted);display:flex;align-items:center">${day}</div>
            ${hours.map(h => {
              // Simulate higher risk in off-hours (0-6, 22-24)
              const isOffHours = h < 6 || h > 21;
              const base  = isOffHours ? Math.random() * 0.4 : Math.random() * 0.3;
              const spike = (h === 2 || h === 3) && (day === 'Tue' || day === 'Wed') ? 0.6 : 0;
              const val   = Math.min(base + spike, 1);
              return `<div class="heatmap-cell" style="background:${colorFor(val)}" title="Day ${day} Hour ${h}: Risk ${Math.round(val*100)}%"></div>`;
            }).join('')}
          `).join('')}
        </div>
        <div style="font-size:10px;color:var(--text-muted);margin-top:6px">Hours (UTC) →</div>
      </div>
    `;
  }

  function renderAnomalyCard(user) {
    if (!user.anomaly) return '';
    const a     = user.anomaly;
    const color = Utils.severityColor(a.severity);

    return `<div class="alert-card ${a.severity.toLowerCase()}" id="ueba-anomaly-${user.id}"
      style="cursor:pointer" onclick="UEBAAgent.showUserDetail('${user.id}')">
      <div class="alert-icon" style="background:${color}18;border:1px solid ${color}30;font-size:20px">${a.icon}</div>
      <div class="alert-body">
        <div class="alert-title">
          ${user.name}
          ${Utils.severityBadge(a.severity)}
          ${MITRE.badge(a.mitreId)}
        </div>
        <div style="font-size:12px;font-weight:600;color:${color};margin-bottom:4px">${a.title}</div>
        <div class="alert-meta">
          <span class="alert-meta-item">👤 ${user.dept}</span>
          <span class="alert-meta-item">🔴 Risk: ${user.riskScore}</span>
          <span class="alert-meta-item">🕐 ${user.loginHours}</span>
        </div>
        <p style="font-size:12px;color:var(--text-secondary);margin:6px 0">${a.detail(user)}</p>
        <div class="alert-actions">
          ${a.severity === 'CRITICAL' ? `
            <button class="btn btn-danger btn-sm" onclick="UEBAAgent.blockUser('${user.id}','${user.name}')">
              🔒 Block via LDAP
            </button>
          ` : ''}
          <button class="btn btn-ghost btn-sm" onclick="UEBAAgent.showUserDetail('${user.id}')">View Profile</button>
          <button class="btn btn-outline btn-sm" onclick="UEBAAgent.emailManager('${user.name}')">📧 Alert Manager</button>
        </div>
      </div>
    </div>`;
  }

  function showUserDetail(userId) {
    const user = users.find(u => u.id === userId);
    if (!user) return;

    const modal   = document.getElementById('ueba-user-modal');
    const content = document.getElementById('ueba-user-modal-content');
    if (!modal || !content) return;

    const a = user.anomaly;
    content.innerHTML = `
      <div style="display:flex;align-items:center;gap:14px;margin-bottom:20px">
        <div class="user-avatar" style="width:52px;height:52px;font-size:20px;background:${user.bgColor};color:${user.riskColor}">
          ${user.avatar}
        </div>
        <div>
          <div style="font-size:18px;font-weight:800">${user.name}</div>
          <div style="font-size:13px;color:var(--text-muted)">${user.dept} — ${user.id}</div>
        </div>
        <div class="risk-score-circle" style="color:${user.riskColor};border-color:${user.riskColor}40;width:52px;height:52px;font-size:18px;margin-left:auto">
          ${user.riskScore}
        </div>
      </div>

      <div class="section-title">Behavior Baseline vs Observed</div>
      <div class="data-table-wrap" style="margin-bottom:16px">
        <table class="data-table">
          <thead><tr><th>Metric</th><th>Baseline (30d)</th><th>Observed (24h)</th><th>Delta</th></tr></thead>
          <tbody>
            <tr>
              <td>Login Time</td>
              <td class="mono">09:00–18:00</td>
              <td class="mono" style="color:${user.hasAnomaly?'var(--accent-red)':'var(--accent-green)'}">${user.loginHours}</td>
              <td>${user.hasAnomaly ? Utils.severityBadge('CRITICAL') : Utils.severityBadge('LOW')}</td>
            </tr>
            <tr>
              <td>Data Transfer</td>
              <td class="mono">${Utils.randomBetween(5,20)} MB/day</td>
              <td class="mono" style="color:${user.hasAnomaly?'var(--accent-red)':'var(--accent-green)'}">${user.dataTransfer}</td>
              <td>${user.hasAnomaly ? Utils.severityBadge('HIGH') : Utils.severityBadge('LOW')}</td>
            </tr>
            <tr>
              <td>Systems Accessed</td>
              <td class="mono">${Utils.randomBetween(3,8)} usual systems</td>
              <td class="mono" style="color:${user.hasAnomaly?'var(--accent-amber)':'var(--accent-green)'}">${Utils.randomBetween(user.hasAnomaly?12:3, user.hasAnomaly?28:8)} systems</td>
              <td>${user.hasAnomaly ? Utils.severityBadge('MEDIUM') : Utils.severityBadge('LOW')}</td>
            </tr>
            <tr>
              <td>Failed Auth Attempts</td>
              <td class="mono">${Utils.randomBetween(0,2)} avg</td>
              <td class="mono" style="color:${user.hasAnomaly?'var(--accent-red)':'var(--accent-green)'}">${user.hasAnomaly ? Utils.randomBetween(5,18) : Utils.randomBetween(0,2)}</td>
              <td>${user.hasAnomaly ? Utils.severityBadge('HIGH') : Utils.severityBadge('LOW')}</td>
            </tr>
          </tbody>
        </table>
      </div>

      ${a ? `
        <div class="section-title">Active Anomaly</div>
        <div class="alert-card critical" style="margin-bottom:16px">
          <div class="alert-icon" style="font-size:22px">${a.icon}</div>
          <div class="alert-body">
            <div class="alert-title">${a.title} ${MITRE.badge(a.mitreId)}</div>
            <p style="font-size:12px;color:var(--text-secondary);margin:6px 0">${a.detail(user)}</p>
          </div>
        </div>
        <div class="remediation-box" style="margin-bottom:16px">
          <div class="rem-title">Recommended Action</div>
          <p style="font-size:12px">${a.remediation}</p>
        </div>
      ` : '<div class="empty-state" style="padding:20px"><div class="empty-state-icon">✅</div><div>No anomalies detected</div></div>'}

      <div style="display:flex;gap:10px;flex-wrap:wrap">
        ${a?.severity === 'CRITICAL' ? `<button class="btn btn-danger" onclick="UEBAAgent.blockUser('${user.id}','${user.name}')">🔒 Block via LDAP</button>` : ''}
        <button class="btn btn-ghost" onclick="UEBAAgent.emailManager('${user.name}')">📧 Alert Security Manager</button>
        <button class="btn btn-ghost" onclick="document.getElementById('ueba-user-modal').classList.add('hidden')">Close</button>
      </div>
    `;

    modal.classList.remove('hidden');
  }

  function blockUser(userId, name) {
    document.getElementById('ueba-user-modal')?.classList.add('hidden');
    Utils.notify(`🔒 LDAP block issued for ${name} — session terminated, access revoked`, 'error', 6000);

    // Update card to show blocked
    const card = document.getElementById(`ueba-anomaly-${userId}`);
    if (card) {
      card.style.opacity = '0.5';
      card.style.border  = '1px solid rgba(255,51,102,0.6)';
    }
  }

  function emailManager(name) {
    document.getElementById('ueba-user-modal')?.classList.add('hidden');
    Utils.notify(`📧 Incident report emailed to Security Manager re: ${name}`, 'success');
  }

  function sendSlackDigest() {
    const modal   = document.getElementById('ueba-slack-modal');
    const content = document.getElementById('ueba-slack-content');
    if (!modal || !content) return;

    const topUsers = [...users].sort((a, b) => b.riskScore - a.riskScore).slice(0, 5);
    const today    = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

    content.innerHTML = `
      <p style="font-size:13px;color:var(--text-secondary);margin-bottom:16px">
        Preview of Slack message that will be posted to #security-alerts:
      </p>
      <div class="code-output" style="margin-bottom:16px;font-size:12px;line-height:1.8">
*🛡️ AI Protect UEBA — Daily Security Digest*
_${today}_
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
*Top 5 Riskiest Users (30-day baseline model)*

${topUsers.map((u, i) => {
  const risk = u.riskScore > 80 ? '🔴' : u.riskScore > 50 ? '🟡' : '🟢';
  return `${i+1}. ${risk} *${u.name}* (${u.dept}) — Risk Score: *${u.riskScore}*${u.hasAnomaly ? `\n   ⚠️ ${u.anomaly?.title}` : ''}`;
}).join('\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 *Summary*: ${users.filter(u=>u.hasAnomaly && u.anomaly?.severity==='CRITICAL').length} Critical | ${users.filter(u=>u.hasAnomaly).length} Flagged | ${users.length} Monitored
🔗 View full report: https://ai-protect.local/ueba/report
</div>
      <div style="display:flex;gap:10px">
        <button class="btn btn-primary" onclick="UEBAAgent.simulateSlack()">💬 Send to Slack</button>
        <button class="btn btn-ghost" onclick="document.getElementById('ueba-slack-modal').classList.add('hidden')">Close</button>
      </div>
    `;

    modal.classList.remove('hidden');
  }

  function simulateSlack() {
    document.getElementById('ueba-slack-modal').classList.add('hidden');
    Utils.notify('✅ Daily digest sent to #security-alerts on Slack', 'success');
    digestSent = true;
  }

  function runAnalysis() {
    users = generateUsers();
    const section = document.querySelector('#ueba .content-section-inner');
    Utils.notify('🔄 UEBA analysis refreshed with new behavioral data', 'info');

    // Re-render anomaly feed
    const feed = document.getElementById('ueba-anomaly-feed');
    if (feed) {
      feed.innerHTML = users.filter(u => u.hasAnomaly).map(u => renderAnomalyCard(u)).join('');
    }

    // Re-render user list
    const list = document.getElementById('ueba-user-list');
    const topUsers = [...users].sort((a, b) => b.riskScore - a.riskScore).slice(0, 5);
    if (list) {
      list.innerHTML = topUsers.map((u, rank) => renderUserCard(u, rank + 1)).join('');
    }
    Utils.animateProgressBars();
  }

  function init() {}

  return { render, init, showUserDetail, blockUser, emailManager, sendSlackDigest, simulateSlack, runAnalysis };
})();
