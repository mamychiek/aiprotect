/* ============================================================
   AI PROTECT — REPORT ENGINE
   Shared formatter for all 5 agents
   ============================================================ */

window.ReportEngine = {

  // ── Summary Table ────────────────────────────────────────────
  summaryTable(counts, title = 'Findings Summary') {
    const total = Object.values(counts).reduce((a, b) => a + b, 0);
    const rows = Object.entries(counts).map(([level, count]) => {
      const cfg = Utils.severityConfig[level] || { color: '#888', icon: '○' };
      const pct  = total ? Math.round(count / total * 100) : 0;
      return `<tr>
        <td>${Utils.severityBadge(level)}</td>
        <td class="mono" style="color:${cfg.color}">${count}</td>
        <td>
          <div class="confidence-track" style="min-width:80px">
            <div class="confidence-fill" style="width:${pct}%;background:${cfg.color}" data-pct="${pct}"></div>
          </div>
        </td>
        <td class="mono" style="color:var(--text-muted)">${pct}%</td>
      </tr>`;
    }).join('');

    return `<div class="card">
      <div class="card-glow"></div>
      <div class="card-header">
        <div class="card-title">📊 ${title}</div>
        <span class="tag">Total: ${total}</span>
      </div>
      <div class="data-table-wrap">
        <table class="data-table">
          <thead><tr>
            <th>Severity</th><th>Count</th><th>Distribution</th><th>%</th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </div>`;
  },

  // ── Finding Card ─────────────────────────────────────────────
  findingCard(finding) {
    const {
      id, severity, title, description,
      component, file, line, snippet,
      recommendation, mitreId, cweId
    } = finding;

    const color = Utils.severityColor(severity);
    const codeBlock = (file && snippet)
      ? Utils.codePointer(file, line || '?', snippet, title)
      : '';

    const mitreBlock = mitreId ? MITRE.badge(mitreId) : '';
    const cweBlock   = cweId
      ? `<span class="tag" title="Common Weakness Enumeration">CWE-${cweId}</span>`
      : '';

    return `<div class="card" style="border-color:${color}22" id="finding-${id}">
      <div style="position:absolute;top:0;left:0;right:0;height:2px;background:${color};border-radius:var(--radius-lg) var(--radius-lg) 0 0"></div>
      <div class="card-header">
        <div>
          <div class="card-title" style="color:${color}">${Utils.severityBadge(severity)} ${title}</div>
          ${component ? `<div class="card-subtitle">📦 ${component}</div>` : ''}
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:flex-start">
          ${mitreBlock} ${cweBlock}
        </div>
      </div>
      <p style="font-size:13px;color:var(--text-secondary);margin-bottom:12px">${description}</p>
      ${codeBlock}
      ${recommendation ? `<div class="remediation-box" style="margin-top:10px">
        <div class="rem-title">✅ Recommendation</div>
        ${recommendation}
      </div>` : ''}
    </div>`;
  },

  // ── Full Report Header ────────────────────────────────────────
  reportHeader(opts) {
    const {
      agentName, target, scanTime, status = 'Completed',
      riskScore, riskLabel
    } = opts;

    const statusColor = status === 'Completed' ? '#00ff88' : '#ffb800';
    const riskColor   = riskScore > 75 ? '#ff3366' : riskScore > 40 ? '#ffb800' : '#00ff88';

    return `<div class="card" style="margin-bottom:20px;background:rgba(0,0,0,0.3)">
      <div class="card-glow"></div>
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:20px;flex-wrap:wrap">
        <div>
          <div style="font-size:11px;color:var(--text-muted);letter-spacing:1px;text-transform:uppercase;margin-bottom:6px">Analysis Report</div>
          <h2 style="margin-bottom:4px;font-size:20px">${agentName}</h2>
          <div style="font-size:13px;color:var(--text-secondary)">🎯 ${target}</div>
          <div style="font-size:12px;color:var(--text-muted);margin-top:4px">
            🕐 ${scanTime}
          </div>
        </div>
        <div style="display:flex;gap:16px;flex-wrap:wrap">
          <div style="text-align:center">
            <div style="font-size:11px;color:var(--text-muted);margin-bottom:4px">STATUS</div>
            <span class="pill" style="color:${statusColor};border-color:${statusColor}40">● ${status}</span>
          </div>
          ${riskScore !== undefined ? `<div style="text-align:center">
            <div style="font-size:11px;color:var(--text-muted);margin-bottom:4px">RISK SCORE</div>
            <div style="font-size:28px;font-weight:900;font-family:var(--font-brand);color:${riskColor};line-height:1">${riskScore}</div>
            <div style="font-size:11px;color:${riskColor}">${riskLabel || ''}</div>
          </div>` : ''}
        </div>
      </div>
    </div>`;
  },

  // ── Findings List ─────────────────────────────────────────────
  findingsList(findings) {
    if (!findings.length) {
      return `<div class="empty-state">
        <div class="empty-state-icon">✅</div>
        <div class="empty-state-text">No findings detected</div>
      </div>`;
    }

    // Sort by severity
    const order = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4 };
    const sorted = [...findings].sort((a, b) => (order[a.severity] || 9) - (order[b.severity] || 9));

    return sorted.map(f => this.findingCard(f)).join('');
  },

  // ── Cloud Findings Table ──────────────────────────────────────
  cloudFindingsTable(findings) {
    const rows = findings.map(f => {
      const color = Utils.severityColor(f.severity);
      return `<tr>
        <td>${Utils.severityBadge(f.severity)}</td>
        <td style="font-weight:600">${f.resource}</td>
        <td style="color:var(--text-secondary)">${f.issue}</td>
        <td><span class="tag">${f.service}</span></td>
        <td><code class="mono" style="font-size:11px">${f.region || 'global'}</code></td>
        <td>
          <button class="btn btn-ghost btn-sm view-fix-btn" data-id="${f.id}">View Fix</button>
        </td>
      </tr>`;
    }).join('');

    return `<div class="data-table-wrap">
      <table class="data-table">
        <thead><tr>
          <th>Severity</th><th>Resource</th><th>Issue</th>
          <th>Service</th><th>Region</th><th>Action</th>
        </tr></thead>
        <tbody>${rows}</tbody>
      </table>
    </div>`;
  },

  // ── Alert Timeline ────────────────────────────────────────────
  alertTimeline(events) {
    return `<div style="display:flex;flex-direction:column;gap:8px">
      ${events.map((ev, i) => {
        const color = Utils.severityColor(ev.severity || 'INFO');
        return `<div class="alert-card ${(ev.severity||'').toLowerCase()}" style="animation-delay:${i*50}ms">
          <div class="alert-icon" style="background:${color}18;border:1px solid ${color}30">
            ${ev.icon || '⚡'}
          </div>
          <div class="alert-body">
            <div class="alert-title">
              ${ev.title}
              ${ev.mitreId ? MITRE.badge(ev.mitreId) : ''}
              ${Utils.severityBadge(ev.severity || 'INFO')}
            </div>
            <div class="alert-meta">
              ${ev.ip ? `<span class="alert-meta-item">🌐 <code class="mono">${ev.ip}</code></span>` : ''}
              ${ev.geo ? `<span class="alert-meta-item">📍 ${ev.geo}</span>` : ''}
              ${ev.time ? `<span class="alert-meta-item">🕐 ${ev.time}</span>` : ''}
              ${ev.confidence ? `<span class="alert-meta-item" style="color:${color}">⚡ ${ev.confidence}% confidence</span>` : ''}
            </div>
            ${ev.remediation ? `<div class="remediation-box" style="margin-top:8px;font-size:12px">
              <div class="rem-title">Remediation</div>
              ${ev.remediation}
              ${ev.remCmd ? `<div class="rem-cmd">${ev.remCmd}</div>` : ''}
            </div>` : ''}
          </div>
        </div>`;
      }).join('')}
    </div>`;
  },

  // ── YARA Rule Generator ───────────────────────────────────────
  generateYARA(meta, strings, condition) {
    const ruleName = 'phishing_' + Date.now();
    const strBlock = strings.map((s, i) =>
      `      $s${i} = ${s.type === 'hex' ? '{' + s.value + '}' : '"' + s.value + '"'} ${s.modifier || ''}`
    ).join('\n');

    return `rule ${ruleName}
{
    meta:
        description = "${meta.description}"
        author = "AI Protect — Phishing Analyzer"
        date = "${new Date().toISOString().slice(0,10)}"
        threat_level = "${meta.threatLevel || 'HIGH'}"
        reference = "${meta.reference || 'N/A'}"

    strings:
${strBlock}

    condition:
        ${condition}
}`;
  },

  // ── Suricata Rule Generator ───────────────────────────────────
  generateSuricata(alert, src, dst, content) {
    const sid = 9000000 + Math.floor(Math.random() * 999999);
    return `alert ${alert.proto || 'http'} ${src || 'any'} any -> ${dst || 'any'} any (
    msg:"AI_PROTECT ${alert.msg}";
    ${content.map(c => `content:"${c}"; nocase;`).join('\n    ')}
    classtype:${alert.classtype || 'trojan-activity'};
    sid:${sid};
    rev:1;
    metadata:created_at ${new Date().toISOString().slice(0,10)}, confidence ${alert.confidence || 'HIGH'};
)`;
  },

  // ── JSON Report Builder ───────────────────────────────────────
  buildJSONReport(agentName, target, findings) {
    return {
      report: {
        agent: agentName,
        version: '1.0.0',
        generated: new Date().toISOString(),
        target,
      },
      summary: {
        total: findings.length,
        critical: findings.filter(f => f.severity === 'CRITICAL').length,
        high:     findings.filter(f => f.severity === 'HIGH').length,
        medium:   findings.filter(f => f.severity === 'MEDIUM').length,
        low:      findings.filter(f => f.severity === 'LOW').length,
      },
      findings,
    };
  },

  // ── CSV Builder ───────────────────────────────────────────────
  buildCSV(findings, fields) {
    const headers = fields || ['id', 'severity', 'title', 'component', 'description', 'recommendation'];
    Utils.downloadCSV(findings, headers, `ai-protect-report-${Date.now()}.csv`);
  },
};
