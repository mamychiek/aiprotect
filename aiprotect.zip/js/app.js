/* ============================================================
   AI PROTECT — APP.JS
   SPA Router, Navigation, Global State
   ============================================================ */

(function () {
  'use strict';

  // ── State ────────────────────────────────────────────────────
  const state = {
    activeAgent: 'dashboard',
    threatLevel: 'LOW',
    globalAlertCount: 0,
  };

  const AGENTS = [
    { id: 'dashboard',  label: 'Overview',               icon: '🏠', module: null },
    { id: 'mobile',     label: 'Mobile Vulnerability',   icon: '📱', module: 'MobileVulnAgent',  badge: null },
    { id: 'monitor',    label: 'Security Monitor',        icon: '🛡️', module: 'BizMonitorAgent',  badge: null, live: true },
    { id: 'cloud',      label: 'Cloud Scanner',           icon: '☁️', module: 'CloudScanAgent',   badge: null },
    { id: 'phishing',   label: 'Phishing Analyzer',       icon: '📧', module: 'PhishingAgent',    badge: null },
    { id: 'ueba',       label: 'Insider Threat (UEBA)',   icon: '👤', module: 'UEBAAgent',         badge: '5' },
  ];

  // ── Clock ────────────────────────────────────────────────────
  function startClock() {
    const el = document.getElementById('header-clock');
    if (!el) return;
    const update = () => {
      const now = new Date();
      el.textContent = now.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    };
    update();
    setInterval(update, 1000);
  }

  // ── Navigation ───────────────────────────────────────────────
  function navigate(agentId) {
    if (state.activeAgent === agentId) return;

    // Deactivate old
    document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.agent-section').forEach(el => el.classList.remove('active'));

    // Activate new
    const navEl     = document.querySelector(`.nav-item[data-agent="${agentId}"]`);
    const sectionEl = document.getElementById(`section-${agentId}`);

    if (navEl)     navEl.classList.add('active');
    if (sectionEl) sectionEl.classList.add('active');

    // Update breadcrumb
    const agent = AGENTS.find(a => a.id === agentId);
    const breadEl = document.getElementById('breadcrumb-current');
    if (breadEl && agent) breadEl.textContent = agent.label;

    // Render agent content if not yet rendered
    if (sectionEl && !sectionEl.dataset.rendered) {
      renderAgent(agentId, sectionEl, agent);
    }

    state.activeAgent = agentId;
  }

  function renderAgent(agentId, sectionEl, agent) {
    if (!agent?.module) return;
    const mod = window[agent.module];
    if (!mod) return;

    sectionEl.innerHTML = `<div class="content-section-inner">${mod.render()}</div>`;
    sectionEl.dataset.rendered = '1';

    if (typeof mod.init === 'function') {
      setTimeout(() => mod.init(), 50);
    }

    Utils.animateProgressBars();
  }

  // ── Dashboard ─────────────────────────────────────────────────
  function renderDashboard() {
    const el = document.getElementById('section-dashboard');
    if (!el || el.dataset.rendered) return;

    el.innerHTML = `
    <div class="content-section-inner">
      <!-- Hero -->
      <div style="text-align:center;padding:32px 0 40px;position:relative">
        <div style="position:absolute;inset:0;background:radial-gradient(ellipse 60% 80% at 50% 0%,rgba(0,255,213,0.06),transparent);pointer-events:none"></div>
        <div style="font-size:48px;margin-bottom:16px;animation:float 3s ease-in-out infinite">🛡️</div>
        <h1 style="font-family:var(--font-brand);font-size:36px;letter-spacing:3px;color:var(--accent-cyan);
          text-shadow:0 0 30px rgba(0,255,213,0.4);margin-bottom:8px">AI PROTECT</h1>
        <p style="font-size:15px;color:var(--text-secondary);max-width:500px;margin:0 auto 24px">
          Multi-Agent Cybersecurity Platform — 5 specialized AI agents protecting your digital infrastructure
        </p>
        <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap">
          <span class="pill" style="color:var(--accent-green);border-color:rgba(0,255,136,0.3)">● 5 Agents Active</span>
          <span class="pill">OWASP · MITRE ATT&CK · CIS</span>
          <span class="pill">Real-time Analysis</span>
        </div>
      </div>

      <!-- Agent Cards -->
      <div class="section-title">Security Agents</div>
      <div class="grid-auto" style="margin-bottom:28px">
        ${[
          {
            id: 'mobile', icon: '📱', label: 'Mobile Vulnerability Scanner',
            desc: 'Decompile APK/IPA · Detect insecure storage · Verify HTTPS · Audit crypto libs',
            color: '#7c3aed', tags: ['OWASP Mobile Top 10', 'CWE', 'SAST'],
            stats: [{ label: 'Vulnerability Classes', value: '10+' }, { label: 'Coverage', value: 'Android + iOS' }]
          },
          {
            id: 'monitor', icon: '🛡️', label: 'Security Monitor',
            desc: 'Live log ingestion · Brute force · Port scan · C2 detection · WhatsApp + Telegram alerts',
            color: '#ff3366', tags: ['MITRE ATT&CK', 'Real-time', 'SIEM'],
            stats: [{ label: 'Detection Patterns', value: '6+' }, { label: 'Alert Channels', value: 'WhatsApp + TG' }],
            live: true
          },
          {
            id: 'cloud', icon: '☁️', label: 'Cloud Misconfiguration Scanner',
            desc: 'AWS · Azure · GCP · Terraform · IAM · S3 · Security Groups · RDS encryption',
            color: '#0066ff', tags: ['CIS Benchmarks', 'AWS Well-Arch', 'IaC'],
            stats: [{ label: 'Cloud Providers', value: 'AWS · Azure · GCP' }, { label: 'Rules', value: '50+' }]
          },
          {
            id: 'phishing', icon: '📧', label: 'Phishing Email Analyzer',
            desc: 'SPF/DKIM/DMARC · URL reputation · IOC extraction · YARA + Suricata rules · SOAR JSON',
            color: '#ffb800', tags: ['VirusTotal', 'YARA', 'SOAR'],
            stats: [{ label: 'Auth Checks', value: 'SPF + DKIM + DMARC' }, { label: 'Output', value: 'YARA + Suricata' }]
          },
          {
            id: 'ueba', icon: '👤', label: 'Insider Threat (UEBA)',
            desc: '30-day behavioral baseline · Impossible travel · Bulk exfiltration · LDAP block · Slack digest',
            color: '#00ffd5', tags: ['UEBA', 'Behavioral AI', 'LDAP'],
            stats: [{ label: 'Baseline Window', value: '30 days' }, { label: 'Alert Channels', value: 'Slack + Email' }]
          },
        ].map(agent => `
          <div class="card" style="cursor:pointer;--card-accent:${agent.color};border-top:2px solid ${agent.color}40"
            onclick="App.navigate('${agent.id}')">
            <div class="card-glow" style="background:linear-gradient(90deg,transparent,${agent.color},transparent)"></div>
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">
              <div style="width:44px;height:44px;border-radius:12px;background:${agent.color}22;
                display:flex;align-items:center;justify-content:center;font-size:22px;
                border:1px solid ${agent.color}40;flex-shrink:0">
                ${agent.icon}
              </div>
              <div>
                <div style="font-size:13px;font-weight:700;color:var(--text-primary)">${agent.label}</div>
                ${agent.live ? `<span style="font-size:10px;color:var(--accent-green);font-weight:700">● LIVE</span>` : ''}
              </div>
            </div>
            <p style="font-size:12px;color:var(--text-secondary);margin-bottom:12px;line-height:1.5">${agent.desc}</p>
            <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px">
              ${agent.tags.map(t => `<span class="tag" style="font-size:10px">${t}</span>`).join('')}
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;padding-top:10px;border-top:1px solid var(--border-dim)">
              ${agent.stats.map(s => `
                <div>
                  <div style="font-size:11px;color:${agent.color};font-weight:700">${s.value}</div>
                  <div style="font-size:10px;color:var(--text-muted)">${s.label}</div>
                </div>
              `).join('')}
            </div>
            <div style="margin-top:12px">
              <span class="btn btn-outline btn-sm" style="width:100%;justify-content:center;color:${agent.color};border-color:${agent.color}40">
                Launch Agent →
              </span>
            </div>
          </div>
        `).join('')}
      </div>

      <!-- Threat Intel Strip -->
      <div class="section-title">Threat Intelligence Feed</div>
      <div class="terminal" style="margin-bottom:0">
        <div class="terminal-header">
          <div class="terminal-dots">
            <div class="terminal-dot red"></div>
            <div class="terminal-dot amber"></div>
            <div class="terminal-dot green"></div>
          </div>
          <span class="terminal-title">threat-intel-feed — global IOC stream</span>
          <span class="pill" style="margin-left:auto;color:var(--accent-green);font-size:10px">● LIVE</span>
        </div>
        <div class="terminal-body" id="dashboard-feed" style="max-height:200px"></div>
      </div>
    </div>
    `;

    el.dataset.rendered = '1';
    startThreatFeed();
  }

  // ── Live Threat Intelligence Feed ────────────────────────────
  function startThreatFeed() {
    const feed = document.getElementById('dashboard-feed');
    if (!feed) return;

    const messages = [
      () => ({ level: 'WARN',  msg: `[VirusTotal] New phishing domain detected: ${Utils.randomHex(6)}-secure-login.xyz` }),
      () => ({ level: 'ERROR', msg: `[Shodan] Exposed Elasticsearch node at ${Utils.randomIP(true)}:9200 — 2.4M records` }),
      () => ({ level: 'WARN',  msg: `[MITRE] New TTPs attributed to APT41 — T1566.001 (Spearphishing Attachment)` }),
      () => ({ level: 'INFO',  msg: `[CVE] CVE-2026-${Utils.randomBetween(1000,9999)} — CVSS 9.8 — OpenSSL heap overflow` }),
      () => ({ level: 'ERROR', msg: `[TOR] Exit node ${Utils.randomIP(true)} used in ${Utils.randomBetween(50,200)} attacks in 24h` }),
      () => ({ level: 'INFO',  msg: `[Blocklist] ${Utils.randomBetween(100,500)} new malicious IPs added to feed` }),
      () => ({ level: 'WARN',  msg: `[Ransomware] LockBit 4.0 targeting healthcare sector — IOCs updated` }),
      () => ({ level: 'INFO',  msg: `[CISA] KEV updated — 3 new actively exploited vulnerabilities added` }),
      () => ({ level: 'SUCCESS', msg: `[AI Protect] Threat intelligence synchronized — ${Utils.randomBetween(50000,99999)} IOCs loaded` }),
    ];

    const addLine = () => {
      if (!document.getElementById('dashboard-feed')) return;
      const entry = Utils.randomChoice(messages)();
      const now   = new Date().toTimeString().slice(0, 8);
      const line  = document.createElement('div');
      line.className = 'log-line';
      line.innerHTML = `
        <span class="log-time">${now}</span>
        <span class="log-level ${entry.level}">${entry.level}</span>
        <span class="log-msg">${entry.msg}</span>
      `;
      feed.appendChild(line);
      while (feed.children.length > 30) feed.removeChild(feed.firstChild);
      feed.scrollTop = feed.scrollHeight;
    };

    // Add initial lines
    for (let i = 0; i < 6; i++) setTimeout(addLine, i * 100);
    setInterval(addLine, 2500);
  }

  // ── Threat Level Updater ──────────────────────────────────────
  function updateThreatLevel() {
    const levels = ['LOW', 'MODERATE', 'HIGH', 'CRITICAL'];
    const colors = { LOW: 'green', MODERATE: 'amber', HIGH: 'amber', CRITICAL: 'red' };

    setInterval(() => {
      const levelEl = document.getElementById('threat-level-text');
      if (!levelEl) return;
      const lvl = Utils.randomChoice(levels.slice(0, 3)); // keep it mostly low/moderate for demo
      levelEl.textContent = lvl;
      levelEl.className   = `threat-level ${colors[lvl] || 'green'}`;
    }, 15000);
  }

  // ── Build DOM Structure ───────────────────────────────────────
  function buildShell() {
    document.getElementById('app').innerHTML = `
      <!-- Sidebar -->
      <aside class="sidebar">
        <div class="sidebar-logo">
          <div class="logo-mark">
            <div class="logo-icon">🛡️</div>
            <div class="logo-text">
              <div class="logo-name">AI PROTECT</div>
              <div class="logo-tagline">Cyber Intelligence Platform</div>
            </div>
          </div>
        </div>

        <nav class="sidebar-nav">
          <div class="nav-section-label">Navigation</div>
          ${AGENTS.map(a => `
            <div class="nav-item${a.id === 'dashboard' ? ' active' : ''}"
              data-agent="${a.id}"
              onclick="App.navigate('${a.id}')">
              <div class="nav-icon">${a.icon}</div>
              <span class="nav-label">${a.label}</span>
              ${a.live ? `<span class="nav-badge green">LIVE</span>` : ''}
              ${a.badge ? `<span class="nav-badge">${a.badge}</span>` : ''}
            </div>
          `).join('')}
        </nav>

        <div class="sidebar-footer">
          <div class="agent-status">
            <div class="status-dot"></div>
            <span>All agents operational</span>
          </div>
          <div style="margin-top:8px;font-size:10px;color:var(--text-muted)">
            AI Protect v1.0.0 · ${new Date().getFullYear()}
          </div>
        </div>
      </aside>

      <!-- Main -->
      <div class="main-wrapper">
        <!-- Header -->
        <header class="header">
          <div class="header-breadcrumb">
            <span style="color:var(--text-muted)">AI Protect</span>
            <span class="breadcrumb-sep">/</span>
            <span class="breadcrumb-current" id="breadcrumb-current">Overview</span>
          </div>
          <div class="header-widgets">
            <div class="threat-gauge">
              <span class="threat-label">Threat Level:</span>
              <span class="threat-level green" id="threat-level-text">LOW</span>
            </div>
            <div class="header-clock" id="header-clock"></div>
          </div>
        </header>

        <!-- Content -->
        <div class="content-area">
          ${AGENTS.map(a => `
            <section class="agent-section${a.id === 'dashboard' ? ' active' : ''}"
              id="section-${a.id}" data-agent="${a.id}">
            </section>
          `).join('')}
        </div>
      </div>
    `;
  }

  // ── Init ─────────────────────────────────────────────────────
  function init() {
    buildShell();
    renderDashboard();
    startClock();
    updateThreatLevel();

    // Animate progress bars when switching tabs
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('confidence-fill')) return;
      setTimeout(() => Utils.animateProgressBars(), 200);
    });

    // Handle UEBA section re-render on nav click
    document.querySelector('.sidebar-nav').addEventListener('click', (e) => {
      const item = e.target.closest('.nav-item');
      if (!item) return;
      setTimeout(() => Utils.animateProgressBars(), 300);
    });
  }

  // ── Public API ────────────────────────────────────────────────
  window.App = { navigate, init };

  // Boot
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
