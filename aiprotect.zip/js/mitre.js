/* ============================================================
   AI PROTECT — MITRE ATT&CK LOOKUP TABLE
   ============================================================ */

window.MITRE = {
  techniques: {
    // Initial Access
    'T1078': { name: 'Valid Accounts',               tactic: 'Initial Access',       color: '#ff3366' },
    'T1190': { name: 'Exploit Public-Facing App',    tactic: 'Initial Access',       color: '#ff3366' },
    'T1566': { name: 'Phishing',                     tactic: 'Initial Access',       color: '#ff3366' },
    'T1133': { name: 'External Remote Services',     tactic: 'Initial Access',       color: '#ff3366' },

    // Execution
    'T1059': { name: 'Command & Scripting Interpreter', tactic: 'Execution',         color: '#ff6600' },
    'T1203': { name: 'Exploitation for Client Exec',    tactic: 'Execution',         color: '#ff6600' },
    'T1204': { name: 'User Execution',                  tactic: 'Execution',         color: '#ff6600' },

    // Persistence
    'T1098': { name: 'Account Manipulation',         tactic: 'Persistence',          color: '#ffb800' },
    'T1136': { name: 'Create Account',               tactic: 'Persistence',          color: '#ffb800' },
    'T1543': { name: 'Create/Modify System Process', tactic: 'Persistence',          color: '#ffb800' },

    // Privilege Escalation
    'T1068': { name: 'Exploitation for Privilege Esc', tactic: 'Privilege Escalation', color: '#ff8c00' },
    'T1548': { name: 'Abuse Elevation Control Mech', tactic: 'Privilege Escalation', color: '#ff8c00' },
    'T1134': { name: 'Access Token Manipulation',    tactic: 'Privilege Escalation', color: '#ff8c00' },

    // Defense Evasion
    'T1027': { name: 'Obfuscated Files or Info',    tactic: 'Defense Evasion',       color: '#9b59b6' },
    'T1036': { name: 'Masquerading',                tactic: 'Defense Evasion',       color: '#9b59b6' },
    'T1070': { name: 'Indicator Removal on Host',   tactic: 'Defense Evasion',       color: '#9b59b6' },

    // Credential Access
    'T1003': { name: 'OS Credential Dumping',       tactic: 'Credential Access',     color: '#e74c3c' },
    'T1110': { name: 'Brute Force',                 tactic: 'Credential Access',     color: '#e74c3c' },
    'T1555': { name: 'Credentials from Stores',     tactic: 'Credential Access',     color: '#e74c3c' },
    'T1539': { name: 'Steal Web Session Cookie',    tactic: 'Credential Access',     color: '#e74c3c' },

    // Discovery
    'T1046': { name: 'Network Service Scanning',    tactic: 'Discovery',             color: '#3498db' },
    'T1082': { name: 'System Information Discovery',tactic: 'Discovery',             color: '#3498db' },
    'T1087': { name: 'Account Discovery',           tactic: 'Discovery',             color: '#3498db' },
    'T1018': { name: 'Remote System Discovery',     tactic: 'Discovery',             color: '#3498db' },

    // Lateral Movement
    'T1021': { name: 'Remote Services',             tactic: 'Lateral Movement',      color: '#1abc9c' },
    'T1550': { name: 'Use Alternate Auth Material', tactic: 'Lateral Movement',      color: '#1abc9c' },

    // Collection
    'T1005': { name: 'Data from Local System',      tactic: 'Collection',            color: '#00b894' },
    'T1039': { name: 'Data from Network Shared Drive', tactic: 'Collection',         color: '#00b894' },
    'T1114': { name: 'Email Collection',            tactic: 'Collection',            color: '#00b894' },
    'T1074': { name: 'Data Staged',                 tactic: 'Collection',            color: '#00b894' },

    // Exfiltration
    'T1048': { name: 'Exfiltration Over Alt Protocol', tactic: 'Exfiltration',      color: '#00cec9' },
    'T1041': { name: 'Exfiltration Over C2 Channel',   tactic: 'Exfiltration',      color: '#00cec9' },
    'T1567': { name: 'Exfiltration to Cloud Storage',  tactic: 'Exfiltration',      color: '#00cec9' },

    // Command and Control
    'T1071': { name: 'App Layer Protocol',          tactic: 'Command and Control',   color: '#6c5ce7' },
    'T1095': { name: 'Non-App Layer Protocol',      tactic: 'Command and Control',   color: '#6c5ce7' },
    'T1219': { name: 'Remote Access Software',      tactic: 'Command and Control',   color: '#6c5ce7' },

    // Impact
    'T1485': { name: 'Data Destruction',            tactic: 'Impact',                color: '#d63031' },
    'T1486': { name: 'Data Encrypted for Impact',   tactic: 'Impact',                color: '#d63031' },
    'T1498': { name: 'Network Denial of Service',   tactic: 'Impact',                color: '#d63031' },
  },

  get(id) {
    return this.techniques[id] || { name: 'Unknown Technique', tactic: 'Unknown', color: '#888' };
  },

  badge(id) {
    const t = this.get(id);
    return `<span class="mitre-badge" style="border-color:${t.color};color:${t.color}" title="${t.name} — ${t.tactic}">
      <span class="mitre-id">${id}</span>
      <span class="mitre-name">${t.name}</span>
    </span>`;
  },

  card(id) {
    const t = this.get(id);
    return `<div class="mitre-card" style="--mitre-color:${t.color}">
      <div class="mitre-card-id">${id}</div>
      <div class="mitre-card-name">${t.name}</div>
      <div class="mitre-card-tactic">${t.tactic}</div>
    </div>`;
  }
};
